# GOLDSTB PRO Terms and Content Disclaimer

Last updated: September 18, 2026

GOLDSTB PRO is an independent media-player client. The application does not include, sell, supply, host, retransmit, or recommend any television channels, streams, playlists, portals, or television subscriptions. An application licence, if offered, is separate from any content-provider subscription.

Users must provide their own portal and account details and may connect only to services and content they are legally authorized to access. Users are solely responsible for confirming that their provider and their use comply with copyright law, licence terms, and all laws applicable in their location. GOLDSTB PRO must not be used to access pirated, unauthorized, infringing, or otherwise unlawful content.

GOLDSTB PRO is not affiliated with, endorsed by, or sponsored by any portal operator, broadcaster, channel, content owner, or third-party media service. Names and trademarks belonging to third parties remain the property of their respective owners.

Third-party portals and media services are outside our control. To the maximum extent permitted by law, no guarantee is made that a particular portal, channel, stream, or service will be available, lawful, accurate, secure, or compatible. Users should obtain independent legal advice where needed.
