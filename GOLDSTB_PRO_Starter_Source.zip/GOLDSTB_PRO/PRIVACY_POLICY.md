# GOLDSTB PRO Privacy Policy

Last updated: September 18, 2026

GOLDSTB PRO holds the portal URL and MAC/account details in memory while the app is being used. These connection details and technical requests are transmitted only to the portal selected by the user so the requested service can operate; this version does not persist those credentials after the app process ends. Favourites and legal-notice acceptance are stored locally on the user's device. The app does not provide or operate television channels, streams, playlists, portals, advertising services, or content subscriptions.

GOLDSTB PRO does not intentionally collect or sell personal information through an operator-controlled analytics or advertising service in this version. A user's chosen portal may independently receive device, account, network, and usage information under that portal operator's own privacy practices. Users should review their provider's policy before connecting.

Removing the app clears its locally stored application data. Users may also clear the data through Android system settings.

Before public distribution, the publisher must add accurate contact information, identify any production analytics or crash-reporting services, and host this policy at a stable public URL required by the applicable app store.
