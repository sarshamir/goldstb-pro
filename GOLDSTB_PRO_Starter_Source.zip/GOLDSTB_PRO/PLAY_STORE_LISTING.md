# GOLDSTB PRO — Google Play Store Listing

## App name

GOLDSTB PRO

## Short description

TV media-player client for your authorized Stalker portal service.

## Full description

GOLDSTB PRO is a remote-friendly media-player client designed for Android TV and compatible television devices.

Connect to a Stalker/MAG-compatible portal that you are legally authorized to use, browse the categories supplied by your provider, save favourites, and play available media with a clean TV interface.

Key features:

- Android TV and television-remote friendly interface
- User-entered portal URL and authorized MAC/account details
- Automatic discovery of common compatible portal endpoint paths
- Category and channel browsing
- One automatically saved portal with startup reconnection
- Channel search, local favourites, and recent channels
- Media3-powered playback
- Clear legal and privacy information inside the app

Important: GOLDSTB PRO is a media player only. It does not include, sell, provide, host, retransmit, or recommend television channels, streams, playlists, portals, or subscriptions. You must obtain access from your own authorized provider and may use the app only with content you are legally entitled to access. An app installation or licence is separate from any content-provider subscription.

## Category

Video Players & Editors

## Contact details

- Email: canadalightsplus@gmail.com
- Website: https://goldvpn.online
- Privacy policy: https://sarshamir.github.io/goldstb-pro/privacy-policy.html

## Release notes — version 0.5.3

- TV search keyboard now opens only after pressing remote OK/select.
- Stronger gold focus highlight and circular selected-channel indicator.
- Portal field displays clean domains without HTTP/HTTPS while both protocols remain supported.
- Preserves forwarded-domain handling, automatic portal start, generated MAC, and VOD caching.

## Previous release — version 0.5.2

- Added support for HTTP redirects and HTML/JavaScript forwarding domains.
- Automatically reconnects the saved portal whenever the app restarts.
- Generates and remembers a unique virtual MAC address on first launch.
- Improves VOD responsiveness with category caching and safer request cancellation.
- Preserves the mini-player, side playlist, full-screen control, and existing playback fixes.

- Forwarded and redirected portal domains are supported
- Mini-player keeps the Live TV or VOD list visible during playback
- Full-screen playback toggle with seamless return to the list
- Responsive side-by-side landscape and stacked portrait layouts

## Previous release — version 0.5.0

- New two-page Live TV and VOD interface
- Colourful feature tiles and deep-gold GOLDSTB branding
- Real portal loading progress and clearer connection status screens
- Dedicated messages for inactive subscriptions, unauthorized MAC addresses, and portal errors

## Previous release — version 0.4.7

- Responsive Live TV, VOD, and category layout for phone screens
- Scrollable category chips with a full-width content list on compact displays
- Improved portrait and landscape sizing while preserving the TV layout

## Previous release — version 0.4.6

Portal addresses now work with or without http:// and https://. Faster concurrent endpoint discovery and parallel category/channel loading reduce connection time. Includes clearer authorization errors, MAC typing fixes, responsive setup, and playback stability improvements.
