# GOLDSTB PRO — Google Play Store Listing

## App name

GOLDSTB PRO

## Short description

TV media-player client for your authorized Stalker portal service.

## Full description

GOLDSTB PRO is a remote-friendly media-player client designed for Android TV and compatible television devices.

Connect to a Stalker/MAG-compatible portal that you are legally authorized to use, browse the categories supplied by your provider, save favourites, and play available media with a clean TV interface.

Key features:

- Android TV and television-remote friendly interface
- User-entered portal URL and authorized MAC/account details
- Automatic discovery of common compatible portal endpoint paths
- Category and channel browsing
- Local favourites
- Media3-powered playback
- Clear legal and privacy information inside the app

Important: GOLDSTB PRO is a media player only. It does not include, sell, provide, host, retransmit, or recommend television channels, streams, playlists, portals, or subscriptions. You must obtain access from your own authorized provider and may use the app only with content you are legally entitled to access. An app installation or licence is separate from any content-provider subscription.

## Category

Video Players & Editors

## Contact details

- Email: canadalightsplus@gmail.com
- Website: https://goldvpn.online
- Privacy policy: https://sarshamir.github.io/goldstb-pro/privacy-policy.html

## Release notes — version 0.3.0

Initial Google Play release of GOLDSTB PRO with Android TV support, authorized portal connection, category browsing, favourites, playback, automatic endpoint detection, and in-app legal/privacy notices.
