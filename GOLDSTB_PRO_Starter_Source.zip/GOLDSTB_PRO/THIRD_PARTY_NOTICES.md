# Third-Party Notices

GOLDSTB PRO uses open-source components, including AndroidX, Jetpack Compose, AndroidX Media3, OkHttp, Kotlin, and Kotlin Coroutines.

These components are distributed under their respective licences. AndroidX, Jetpack Compose, AndroidX Media3, OkHttp, Kotlin, and Kotlin Coroutines are commonly distributed under the Apache License 2.0. Copyright remains with their respective authors and contributors.

Apache License 2.0: https://www.apache.org/licenses/LICENSE-2.0

This notice does not replace the licence files or notices supplied with those components. A production release should preserve all notices required by the exact dependency versions included in the final build.
