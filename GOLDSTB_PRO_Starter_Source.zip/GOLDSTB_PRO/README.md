# GOLDSTB PRO

Original Android TV / Amazon Fire TV starter client for authorized Stalker/MAG portals.

## Included

- TV launcher support and remote-friendly dark/gold interface
- User-entered portal URL and MAC address (nothing is hard-coded)
- Portal handshake, profile initialization, categories and channel retrieval
- Stream-link resolution and Media3 playback
- Favorites stored locally
- HTTPS-first URL handling with compatibility for explicitly entered HTTP URLs

## Open and run

1. Install Android Studio (JDK 17 support).
2. Open the `GOLDSTB_PRO` folder.
3. Let Android Studio sync Gradle dependencies.
4. Run on an Android TV emulator, Android TV box, or Fire TV development device.
5. Enter a portal URL and an account/MAC you are authorized to use.

## Security and release notes

- Do not embed customer credentials in source code or release builds.
- Cleartext HTTP is enabled only for legacy portal compatibility; use HTTPS whenever available.
- Before store submission, replace the temporary vector launcher art with final adaptive-icon and TV-banner exports, add a privacy policy, complete device testing, and confirm content/provider authorization.
- Portal implementations vary. If an authorized server uses a different endpoint path or parameters, adapt `PortalClient.kt` based on its documented API.

This project does not scan, generate, or test third-party MAC addresses and does not bypass portal authorization.

## Private GitHub APK build

Push this folder to a private GitHub repository. The included workflow builds a debug APK on every push to `main`, or manually from the repository's **Actions** tab. Download `GOLDSTB-PRO-debug-apk` from the completed workflow run.
