# GOLDSTB PRO

Original Android TV / Amazon Fire TV starter client for authorized Stalker/MAG portals.

## Included

- TV launcher support and a familiar three-panel, remote-friendly dark/gold interface
- User-entered portal URL and MAC address (nothing is hard-coded)
- Portal handshake, profile initialization, categories and channel retrieval
- Automatic discovery of common authorized Stalker portal endpoint paths
- Stream-link resolution and Media3 playback
- One portal and authorized MAC address saved automatically
- Automatic portal connection whenever the app starts
- Channel search, favorites, and recent-channel history
- HTTPS-first URL handling with compatibility for explicitly entered HTTP URLs
- First-run legal acceptance and a permanently accessible Legal & Privacy screen
- Clear notice that the app supplies no channels, streams, portals, playlists, or subscriptions

## Open and run

1. Install Android Studio (JDK 17 support).
2. Open the `GOLDSTB_PRO` folder.
3. Let Android Studio sync Gradle dependencies.
4. Run on an Android TV emulator, Android TV box, or Fire TV development device.
5. Enter a portal URL and an account/MAC you are authorized to use.

## Security and release notes

- Do not embed customer credentials in source code or release builds.
- Cleartext HTTP is enabled only for legacy portal compatibility; use HTTPS whenever available.
- Before store submission, complete physical Android TV device testing and confirm content/provider authorization.
- Portal implementations vary. If an authorized server uses a different endpoint path or parameters, adapt `PortalClient.kt` based on its documented API.

This project does not scan, generate, or test third-party MAC addresses and does not bypass portal authorization.

## Content disclaimer

GOLDSTB PRO is an independent media-player client. It does not include, sell, supply, host, retransmit, or recommend channels, streams, playlists, portals, or TV subscriptions. Users must supply their own access details and may connect only to services and content they are legally authorized to use. An app licence, if offered, is separate from any content-provider subscription.

See `TERMS_AND_DISCLAIMER.md`, `PRIVACY_POLICY.md`, and `THIRD_PARTY_NOTICES.md`. Store publication still requires review by qualified counsel and a publicly hosted privacy-policy URL.

## Private GitHub APK build

Push this folder to a private GitHub repository. The included workflow builds a debug APK on every push to `main`, or manually from the repository's **Actions** tab. Download `GOLDSTB-PRO-debug-apk` from the completed workflow run.
