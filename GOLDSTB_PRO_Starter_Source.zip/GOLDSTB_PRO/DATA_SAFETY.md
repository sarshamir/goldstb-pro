# Google Play Data Safety Draft

This draft describes version 0.3.0 and must be reviewed again if analytics, advertising, crash reporting, accounts, payments, or other SDKs are added.

## Collection and sharing

- No developer-operated analytics or advertising collection.
- No personal data sold by the app publisher.
- Portal URL and MAC/account details are entered by the user and transmitted to the third-party portal selected by that user to provide the requested functionality.
- Those portal credentials are held in app memory during use and are not intentionally persisted after the app process ends in this version.
- Favourites and legal-notice acceptance are stored locally on the device and are not sent to the publisher.

## Suggested Play Console answers

- Does the app collect or share required user data with the developer? **No**, subject to Play Console's current definition and confirmation that no production SDK changes are made.
- Is all data encrypted in transit? **No / not guaranteed**, because the app supports user-selected legacy HTTP portals. Store reviewers should be told that HTTPS is preferred but compatibility mode permits HTTP when explicitly entered by the user.
- Can users request deletion? **Not applicable for publisher-held data**; users can clear local app data or uninstall the app.

The selected third-party portal may independently process account, network, device, and usage data under its own privacy terms. The publisher does not control that provider.
