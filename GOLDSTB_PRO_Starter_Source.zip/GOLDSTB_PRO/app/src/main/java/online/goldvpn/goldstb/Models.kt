package online.goldvpn.goldstb

data class PortalConfig(val baseUrl: String, val mac: String)
data class Category(val id: String, val title: String)
data class Channel(val id: String, val name: String, val command: String, val categoryId: String)
data class PlaybackSource(val url: String, val headers: Map<String, String>)

sealed interface Screen {
    data object Setup : Screen
    data object Channels : Screen
    data class Player(val channel: Channel, val source: PlaybackSource) : Screen
}

data class AppState(
    val screen: Screen = Screen.Setup,
    val busy: Boolean = false,
    val error: String? = null,
    val config: PortalConfig? = null,
    val categories: List<Category> = emptyList(),
    val channels: List<Channel> = emptyList(),
    val selectedCategory: String? = null,
    val favorites: Set<String> = emptySet(),
    val recentChannelIds: List<String> = emptyList(),
    val query: String = "",
    val connectionLabel: String? = null
)
