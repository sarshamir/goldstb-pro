package online.goldvpn.goldstb

data class PortalConfig(val baseUrl: String, val mac: String)
enum class MediaKind { LIVE, VOD }
data class Category(val id: String, val title: String, val kind: MediaKind = MediaKind.LIVE)
data class Channel(
    val id: String,
    val name: String,
    val command: String,
    val categoryId: String,
    val kind: MediaKind = MediaKind.LIVE,
    val poster: String = ""
)
data class PortalContent(
    val liveCategories: List<Category>,
    val liveChannels: List<Channel>,
    val vodCategories: List<Category>,
    val accountInfo: AccountInfo = AccountInfo()
)
data class AccountInfo(
    val username: String = "",
    val status: String = "",
    val expires: String = "",
    val plan: String = "",
    val server: String = ""
)
data class PlaybackSource(val url: String, val headers: Map<String, String>)

enum class ConnectionProblem { NO_INTERNET, NOT_AUTHORIZED, PORTAL_NOT_FOUND, EXPIRED_OR_BLOCKED, INVALID_RESPONSE, NETWORK }

sealed interface Screen {
    data object Setup : Screen
    data object Library : Screen
    data object Content : Screen
    data class ConnectionError(val type: ConnectionProblem, val message: String) : Screen
    data class Player(val channel: Channel, val source: PlaybackSource) : Screen
}

data class AppState(
    val screen: Screen = Screen.Setup,
    val busy: Boolean = false,
    val loadingProgress: Float = 0f,
    val error: String? = null,
    val config: PortalConfig? = null,
    val liveCategories: List<Category> = emptyList(),
    val vodCategories: List<Category> = emptyList(),
    val liveChannels: List<Channel> = emptyList(),
    val vodItems: List<Channel> = emptyList(),
    val selectedKind: MediaKind = MediaKind.LIVE,
    val selectedCategory: String? = null,
    val selectedCategoryTitle: String = "All",
    val favorites: Set<String> = emptySet(),
    val recentChannelIds: List<String> = emptyList(),
    val query: String = "",
    val resolvingChannel: Channel? = null,
    val connectionLabel: String? = null,
    val accountInfo: AccountInfo = AccountInfo(),
    val settingsMessage: String? = null
)
