package online.goldvpn.goldstb

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

class PortalClient {
    private val cookieJar = object : CookieJar {
        private val cookies = ConcurrentHashMap<String, List<Cookie>>()
        override fun saveFromResponse(url: HttpUrl, newCookies: List<Cookie>) {
            cookies[url.host] = (newCookies + cookies[url.host].orEmpty()).distinctBy { "${it.name}|${it.path}" }
        }
        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            val saved = cookies.values.flatten().filter { it.matches(url) }
            if (!::config.isInitialized) return saved
            val device = listOf(
                Cookie.Builder().name("mac").value(config.mac).hostOnlyDomain(url.host).path("/").build(),
                Cookie.Builder().name("stb_lang").value("en").hostOnlyDomain(url.host).path("/").build(),
                Cookie.Builder().name("timezone").value("UTC").hostOnlyDomain(url.host).path("/").build()
            )
            return (device + saved).distinctBy { "${it.name}|${it.path}" }
        }
    }

    private val http = OkHttpClient.Builder()
        .connectTimeout(18, TimeUnit.SECONDS).readTimeout(35, TimeUnit.SECONDS)
        .followRedirects(true).followSslRedirects(true).cookieJar(cookieJar).build()
    private val discoveryHttp = http.newBuilder().callTimeout(50, TimeUnit.SECONDS).build()
    private var token = ""
    private lateinit var config: PortalConfig
    private var endpointUrl = ""
    private val itemCache = ConcurrentHashMap<String, List<Channel>>()
    private val episodeCache = ConcurrentHashMap<String, List<Channel>>()
    private val lockedCategoryIds = ConcurrentHashMap.newKeySet<String>()

    suspend fun connect(input: PortalConfig, progress: (Float, String) -> Unit = { _, _ -> }): PortalContent = withContext(Dispatchers.IO) {
        config = input.copy(baseUrl = normalizeBase(input.baseUrl), mac = normalizeMac(input.mac))
        token = ""; endpointUrl = ""; clearCache()
        connectStalker(progress)
    }

    fun clearCache() { itemCache.clear(); episodeCache.clear(); lockedCategoryIds.clear() }

    suspend fun loadItems(kind: MediaKind, categoryId: String?): List<Channel> = withContext(Dispatchers.IO) {
        val key = "$kind:${categoryId ?: "*"}"
        itemCache[key]?.let { return@withContext it }
        val items = loadStalkerItems(kind, categoryId)
        itemCache[key] = items
        items
    }

    suspend fun loadEpisodes(series: Channel): List<Channel> = withContext(Dispatchers.IO) {
        episodeCache[series.id]?.let { return@withContext it }
        val episodes = loadStalkerEpisodes(series)
        episodeCache[series.id] = episodes
        episodes
    }

    suspend fun resolve(channel: Channel, parentalCode: String? = null): PlaybackSource = withContext(Dispatchers.IO) {
        if (channel.command.startsWith("http://") || channel.command.startsWith("https://")) {
            return@withContext PlaybackSource(channel.command, playbackHeaders())
        }
        val type = if (channel.kind == MediaKind.LIVE) "itv" else "vod"
        val candidates = if (channel.kind == MediaKind.LIVE) listOf("0") else listOf(channel.series, "1", "0").filter(String::isNotBlank).distinct()
        var lastError: Throwable? = null
        for (series in candidates) {
            val result = runCatching {
                val protection = parentalCode?.takeIf(String::isNotBlank)?.let { "&protect_code=${encode(it)}&pin=${encode(it)}&password=${encode(it)}" }.orEmpty()
                val json = call("type=$type&action=create_link&cmd=${encode(channel.command)}&series=${encode(series)}$protection&forced_storage=undefined&disable_ad=0&download=0&JsHttpRequest=1-xml")
                payloadObject(json)?.optString("cmd").orEmpty().substringAfter(" ").trim().removeSurrounding("\"").removeSurrounding("'")
                    .takeIf { it.startsWith("http://") || it.startsWith("https://") || it.startsWith("rtsp://") }
                    ?: error("Portal did not return a supported stream URL.")
            }
            if (result.isSuccess) return@withContext PlaybackSource(result.getOrThrow(), playbackHeaders())
            lastError = result.exceptionOrNull()
        }
        throw lastError ?: IllegalStateException("Portal did not return a supported stream URL.")
    }

    private suspend fun connectStalker(progress: (Float, String) -> Unit): PortalContent {
        progress(.1f, "Finding Stalker portal…")
        token = payloadObject(discoverEndpointAndHandshake())?.optString("token").orEmpty()
        require(token.isNotBlank()) { "Portal did not return an authorization token." }
        progress(.3f, "Authorizing MAC…")
        val profile = runCatching { call("type=stb&action=get_profile&JsHttpRequest=1-xml") }.getOrNull()
        val profileJs = profile?.let(::payloadObject)
        val blocked = profileJs?.optString("blocked").orEmpty()
        val status = profileJs?.optString("status").orEmpty()
        require(!(blocked == "1" || status.equals("blocked", true) || status.equals("expired", true))) { "This subscription is expired or blocked by the provider." }
        progress(.52f, "Loading categories…")
        val results = coroutineScope {
            listOf(
                async { call("type=itv&action=get_genres&JsHttpRequest=1-xml") },
                async { call("type=itv&action=get_all_channels&JsHttpRequest=1-xml") },
                async { runCatching { call("type=vod&action=get_categories&JsHttpRequest=1-xml") }.getOrElse { JSONObject() } }
            ).awaitAll()
        }
        val liveCategories = parseStalkerCategories(results[0], MediaKind.LIVE)
        val vodCategories = parseStalkerCategories(results[2], MediaKind.VOD)
        progress(1f, "Ready")
        return PortalContent(liveCategories, parseStalkerLive(results[1]), vodCategories,
            vodCategories.map { it.copy(kind = MediaKind.SERIES) }, accountInfo(profileJs))
    }

    private fun parseStalkerCategories(root: JSONObject, kind: MediaKind): List<Category> {
        val array = payloadArray(root) ?: return emptyList()
        return buildList { for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            item.optString("id").takeIf(String::isNotBlank)?.let { id ->
                val locked = isLocked(item)
                if (locked) lockedCategoryIds.add("$kind:$id")
                add(Category(id, item.optString("title", "Other"), kind, locked))
            }
        } }
    }

    private fun parseStalkerLive(root: JSONObject): List<Channel> {
        val array = payloadObject(root)?.optJSONArray("data") ?: payloadArray(root) ?: return emptyList()
        return buildList { for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val id = item.optString("id"); val cmd = item.optString("cmd")
            val categoryId = item.optString("tv_genre_id")
            if (id.isNotBlank() && cmd.isNotBlank()) add(Channel(id, item.optString("name", "Channel"), cmd, categoryId, MediaKind.LIVE, item.optString("logo"), locked = isLocked(item) || "${MediaKind.LIVE}:$categoryId" in lockedCategoryIds))
        } }
    }

    private fun loadStalkerItems(kind: MediaKind, categoryId: String?): List<Channel> {
        val categoryQuery = categoryId?.takeIf(String::isNotBlank)?.let { "&category=${encode(it)}" }.orEmpty()
        val collected = LinkedHashMap<String, Channel>()
        val pageSignatures = mutableSetOf<String>()
        var page = 1
        var rawLoaded = 0
        var total = Int.MAX_VALUE
        while (page <= MAX_STALKER_PAGES && rawLoaded < total) {
            val json = call("type=vod&action=get_ordered_list$categoryQuery&p=$page&sortby=added&JsHttpRequest=1-xml")
            val payload = payloadObject(json)
            val array = payload?.optJSONArray("data") ?: payloadArray(json) ?: break
            total = payload?.optInt("total_items", Int.MAX_VALUE)?.takeIf { it > 0 } ?: total
            if (array.length() == 0) break
            val signature = buildString { for (i in 0 until array.length()) append(array.optJSONObject(i)?.optString("id")).append('|') }
            if (!pageSignatures.add(signature)) break
            rawLoaded += array.length()
            for (i in 0 until array.length()) {
                val channel = stalkerVodItem(array.optJSONObject(i) ?: continue, categoryId.orEmpty()) ?: continue
                val wanted = if (kind == MediaKind.SERIES) channel.isContainer else !channel.isContainer
                if (wanted) collected.putIfAbsent(channel.id, channel)
            }
            val pageSize = payload?.optInt("max_page_items", 0)?.takeIf { it > 0 } ?: 10
            if (array.length() < pageSize) break
            page++
        }
        return collected.values.toList()
    }

    private fun stalkerVodItem(item: JSONObject, categoryId: String): Channel? {
        val id = item.optString("id"); val cmd = item.optString("cmd")
        if (id.isBlank() || cmd.isBlank()) return null
        val rawSeries = item.opt("series")
        val refs = episodeReferences(rawSeries)
        val isSeries = item.optInt("is_series", 0) == 1 || item.optString("type").contains("series", true) || rawSeries is JSONArray || refs.size > 1
        return Channel(id, item.optString("name", if (isSeries) "Series" else "Movie"), cmd, categoryId,
            if (isSeries) MediaKind.SERIES else MediaKind.VOD, item.optString("screenshot_uri"),
            refs.firstOrNull() ?: if (isSeries) "1" else "0", item.optString("container_format"), refs, isSeries, isLocked(item) || "${MediaKind.VOD}:$categoryId" in lockedCategoryIds)
    }

    private fun loadStalkerEpisodes(series: Channel): List<Channel> {
        var refs = series.episodeRefs
        if (refs.isEmpty()) {
            for (query in listOf("type=vod&action=get_episodes&id=${encode(series.id)}&JsHttpRequest=1-xml", "type=vod&action=get_series&id=${encode(series.id)}&JsHttpRequest=1-xml")) {
                val json = runCatching { call(query) }.getOrNull() ?: continue
                refs = episodeReferences(payloadObject(json)?.opt("data") ?: payloadArray(json))
                if (refs.isNotEmpty()) break
            }
        }
        if (refs.isEmpty()) refs = listOfNotNull(series.series.takeIf { it.isNotBlank() && it != "0" })
        return refs.mapIndexed { index, ref -> Channel("${series.id}:$ref", if (ref.toIntOrNull() != null) "Episode $ref" else "Episode ${index + 1}",
            series.command, series.categoryId, MediaKind.SERIES, series.poster, ref, series.extension, locked = series.locked) }
    }

    private fun episodeReferences(value: Any?): List<String> = when (value) {
        is JSONArray -> buildList { for (i in 0 until value.length()) when (val entry = value.opt(i)) {
            is JSONObject -> listOf("id", "series", "episode", "episode_num", "number").firstNotNullOfOrNull { key -> entry.opt(key)?.toString()?.takeIf(String::isNotBlank) }?.let(::add)
            is JSONArray -> addAll(episodeReferences(entry))
            null, JSONObject.NULL -> Unit
            else -> entry.toString().takeIf(String::isNotBlank)?.let(::add)
        } }
        is JSONObject -> value.keys().asSequence().flatMap { episodeReferences(value.opt(it)).asSequence() }.toList()
        is String -> when { value.isBlank() || value == "0" -> emptyList(); value.trim().startsWith("[") -> runCatching { episodeReferences(JSONArray(value)) }.getOrDefault(emptyList()); else -> listOf(value) }
        is Number -> listOf(value.toString())
        else -> emptyList()
    }.distinct()

    private fun playbackHeaders(): Map<String, String> = buildMap {
        put("User-Agent", USER_AGENT)
        put("X-User-Agent", "Model: MAG250; Link: WiFi"); put("Cookie", "mac=${config.mac}; stb_lang=en; timezone=UTC")
        put("Referer", "${config.baseUrl}/"); if (token.isNotBlank()) put("Authorization", "Bearer $token")
    }

    private fun call(query: String): JSONObject { check(endpointUrl.isNotBlank()) { "Portal endpoint has not been initialized." }; return request(endpointUrl, query) }

    private suspend fun discoverEndpointAndHandshake(): JSONObject = coroutineScope {
        val entered = config.baseUrl.trimEnd('/')
        val withoutPortalPath = entered.replace(Regex("(?i)/(c|server/load\\.php|stalker_portal/server/load\\.php|stalker_portal/portal\\.php|portal\\.php)$"), "")
        val initialRoots = buildList {
            add(entered); add(withoutPortalPath)
            listOf(entered, withoutPortalPath).forEach { value ->
                if (value.startsWith("https://")) add("http://${value.removePrefix("https://")}")
                if (value.startsWith("http://")) add("https://${value.removePrefix("http://")}")
            }
        }.distinct()
        val forwardedRoots = initialRoots.map { root -> async { runCatching { followForwardingPage(root) }.getOrDefault(root) } }.awaitAll()
        val roots = (forwardedRoots + initialRoots).flatMap(::portalRootVariants).distinct()
        val candidates = buildList { roots.forEach { root -> if (root.endsWith(".php", true)) add(root) else {
            add("$root/server/load.php"); add("$root/portal.php"); add("$root/stalker_portal/server/load.php"); add("$root/stalker_portal/portal.php"); add("$root/c/portal.php")
        } } }.distinct()
        val winner = CompletableDeferred<Pair<String, JSONObject>>(); val noToken = AtomicBoolean(false); val lastError = AtomicReference<Throwable?>(null)
        val jobs = candidates.map { candidate -> launch {
            val result = runCatching { requestResult(candidate, "type=stb&action=handshake&token=&JsHttpRequest=1-xml", discoveryHttp) }
            val response = result.getOrNull(); val json = response?.first
            if (json != null && payloadObject(json)?.optString("token").orEmpty().isNotBlank()) winner.complete(response.second to json) else if (json != null) noToken.set(true)
            result.exceptionOrNull()?.let(lastError::set)
        } }
        val match = withTimeoutOrNull(60_000) { winner.await() }; jobs.forEach { it.cancel() }
        if (match != null) { endpointUrl = match.first; config = config.copy(baseUrl = portalBase(match.first)); return@coroutineScope match.second }
        if (noToken.get()) throw IllegalArgumentException("Portal found, but this MAC address is not authorized by the provider.")
        throw IllegalArgumentException("Unable to find a compatible authorized portal endpoint.", lastError.get())
    }

    private fun portalBase(endpoint: String): String = endpoint.replace(Regex("(?i)/(c/portal\\.php|server/load\\.php|portal\\.php|stalker_portal/server/load\\.php|stalker_portal/portal\\.php)$"), "").trimEnd('/')
    private fun request(endpoint: String, query: String, client: OkHttpClient = http): JSONObject = requestResult(endpoint, query, client).first

    private fun requestResult(endpoint: String, query: String, client: OkHttpClient = http): Pair<JSONObject, String> {
        val url = "$endpoint?$query"
        val request = stalkerRequest(url)
        return client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty(); require(response.isSuccessful) { "Portal returned HTTP ${response.code}." }
            parseObject(body) to response.request.url.newBuilder().query(null).build().toString().trimEnd('/')
        }
    }

    private fun stalkerRequest(url: String): Request = Request.Builder().url(url).header("User-Agent", USER_AGENT)
        .header("X-User-Agent", "Model: MAG250; Link: WiFi").header("Cookie", "mac=${config.mac}; stb_lang=en; timezone=UTC")
        .apply { if (token.isNotBlank()) header("Authorization", "Bearer $token") }.build()

    private fun followForwardingPage(start: String): String {
        var current = start
        repeat(8) {
            val request = Request.Builder().url(current).header("User-Agent", USER_AGENT).header("X-User-Agent", "Model: MAG250; Link: WiFi").build()
            discoveryHttp.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return current
                val finalUrl = response.request.url; val body = response.body?.string().orEmpty()
                val target = forwardingTarget(body) ?: forwardingQueryTarget(finalUrl) ?: return finalUrl.toString().trimEnd('/')
                val next = (finalUrl.resolve(target) ?: return finalUrl.toString().trimEnd('/')).toString().trimEnd('/')
                if (next == current.trimEnd('/')) return next else current = next
            }
        }
        return current.trimEnd('/')
    }

    private fun forwardingTarget(body: String): String? {
        if (body.isBlank() || body.length > 1_000_000) return null
        val patterns = listOf(
            Regex("(?is)<meta[^>]+content\\s*=\\s*[\\\"'][^\\\"']*url\\s*=\\s*([^\\\"'>; ]+)"),
            Regex("(?is)(?:window\\.)?location(?:\\.href)?\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']"),
            Regex("(?is)location\\.(?:replace|assign)\\(\\s*[\\\"']([^\\\"']+)[\\\"']"),
            Regex("(?is)<iframe[^>]+src\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']"),
            Regex("(?is)(?:redirect|portal|target|destination|url)\\s*[:=]\\s*[\\\"']((?:https?:)?\\/\\/[^\\\"']+)[\\\"']")
        )
        return patterns.firstNotNullOfOrNull { it.find(body)?.groupValues?.getOrNull(1) }?.replace("&amp;", "&")?.replace("\\/", "/")?.trim()
    }

    private fun forwardingQueryTarget(url: HttpUrl): String? {
        return listOf("url", "target", "redirect", "redirect_url", "destination", "portal").firstNotNullOfOrNull { key ->
            url.queryParameter(key)?.takeIf(String::isNotBlank)?.let { runCatching { URLDecoder.decode(it, Charsets.UTF_8.name()) }.getOrDefault(it) }
        }?.takeIf { it.startsWith("http://", true) || it.startsWith("https://", true) }
    }

    private fun portalRootVariants(value: String): List<String> {
        val clean = value.substringBefore('#').substringBefore('?').trimEnd('/'); val parsed = clean.toHttpUrlOrNull() ?: return listOf(clean)
        val origin = parsed.newBuilder().encodedPath("/").query(null).fragment(null).build().toString().trimEnd('/')
        val withoutPage = clean.replace(Regex("(?i)/(?:index|home|redirect|forward)?\\.(?:php|html?)$"), "")
        val withoutEntry = withoutPage.replace(Regex("(?i)/(?:c|stalker_portal/c)$"), "")
        return listOf(clean, withoutPage, withoutEntry, origin).filter(String::isNotBlank).distinct()
    }

    private fun accountInfo(profile: JSONObject?): AccountInfo {
        if (profile == null) return AccountInfo()
        fun first(vararg keys: String): String = keys.firstNotNullOfOrNull { key -> profile.opt(key)?.toString()?.trim()?.takeUnless { it.isBlank() || it.equals("null", true) } }.orEmpty()
        return AccountInfo(first("name", "username", "login", "account_name", "fname"), first("status", "account_status", "blocked"), first("expire_billing_date", "expires", "expiration", "end_date"), first("tariff_plan", "tariff_plan_name", "plan", "package"), first("server", "server_name", "portal"))
    }

    private fun parseObject(body: String): JSONObject {
        val cleaned = body.trim().removePrefix("\uFEFF"); require(cleaned.isNotBlank()) { "Portal returned an empty response." }
        val start = cleaned.indexOf('{'); val end = cleaned.lastIndexOf('}')
        require(start >= 0 && end > start) { if (cleaned.startsWith("<")) "Portal returned a web page instead of portal data." else "Portal returned an unsupported response." }
        return try { JSONObject(cleaned.substring(start, end + 1)) } catch (_: JSONException) { throw IllegalArgumentException("Portal returned invalid JSON data.") }
    }
    private fun payloadObject(root: JSONObject): JSONObject? = when (val value = root.opt("js")) { is JSONObject -> value; is String -> runCatching { JSONObject(value) }.getOrNull(); else -> null }
    private fun payloadArray(root: JSONObject): JSONArray? = when (val value = root.opt("js")) { is JSONArray -> value; is JSONObject -> value.optJSONArray("data"); is String -> runCatching { JSONArray(value) }.getOrNull() ?: runCatching { JSONObject(value).optJSONArray("data") }.getOrNull(); else -> null }
    private fun normalizeBase(value: String): String { val raw = value.trim().trimEnd('/'); return if (raw.startsWith("http://", true) || raw.startsWith("https://", true)) raw else "https://$raw" }
    private fun normalizeMac(value: String): String { val mac = value.trim().replace(';', ':').uppercase(); require(Regex("^([0-9A-F]{2}:){5}[0-9A-F]{2}$").matches(mac)) { "Enter a valid MAC address." }; return mac }
    private fun encode(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name())
    private fun isLocked(item: JSONObject): Boolean = listOf("censored", "locked", "is_locked", "protected", "is_protected", "adult")
        .any { key -> item.opt(key)?.toString() == "1" || item.opt(key)?.toString().equals("true", true) }

    private companion object {
        const val MAX_STALKER_PAGES = 250
        const val USER_AGENT = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3"
    }
}
