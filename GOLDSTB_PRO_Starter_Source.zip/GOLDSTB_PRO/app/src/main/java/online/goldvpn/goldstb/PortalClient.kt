package online.goldvpn.goldstb

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.TimeUnit

class PortalClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()
    private val discoveryHttp = http.newBuilder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(7, TimeUnit.SECONDS)
        .build()
    private var token: String = ""
    private lateinit var config: PortalConfig
    private var endpointUrl: String = ""

    suspend fun connect(input: PortalConfig): Pair<List<Category>, List<Channel>> = withContext(Dispatchers.IO) {
        config = input.copy(baseUrl = normalizeBase(input.baseUrl), mac = normalizeMac(input.mac))
        token = ""
        val handshake = discoverEndpointAndHandshake()
        token = payloadObject(handshake)?.optString("token").orEmpty()
        require(token.isNotBlank()) { "Portal did not return an authorization token." }
        // A profile request completes initialization on many authorized Stalker/MAG portals.
        runCatching { call("type=stb&action=get_profile&JsHttpRequest=1-xml") }
        val (categoryJson, channelJson) = coroutineScope {
            listOf(
                async { call("type=itv&action=get_genres&JsHttpRequest=1-xml") },
                async { call("type=itv&action=get_all_channels&JsHttpRequest=1-xml") }
            ).awaitAll()
        }
        val categoriesArray = payloadArray(categoryJson)
        val categories = buildList {
            if (categoriesArray != null) for (i in 0 until categoriesArray.length()) {
                val item = categoriesArray.optJSONObject(i) ?: continue
                add(Category(item.optString("id"), item.optString("title", "Other")))
            }
        }
        val channelsArray = payloadObject(channelJson)?.optJSONArray("data")
            ?: payloadArray(channelJson)
        val channels = buildList {
            if (channelsArray != null) for (i in 0 until channelsArray.length()) {
                val item = channelsArray.optJSONObject(i) ?: continue
                val id = item.optString("id")
                val name = item.optString("name", "Channel")
                val cmd = item.optString("cmd")
                if (id.isNotBlank() && cmd.isNotBlank()) add(Channel(id, name, cmd, item.optString("tv_genre_id")))
            }
        }
        categories to channels
    }

    suspend fun resolve(channel: Channel): PlaybackSource = withContext(Dispatchers.IO) {
        val encoded = URLEncoder.encode(channel.command, Charsets.UTF_8.name())
        val json = call("type=itv&action=create_link&cmd=$encoded&series=0&forced_storage=undefined&disable_ad=0&download=0&JsHttpRequest=1-xml")
        val cmd = payloadObject(json)?.optString("cmd").orEmpty()
        val url = cmd.substringAfter(" ", cmd).trim()
            .removeSurrounding("\"")
            .removeSurrounding("'")
        require(url.startsWith("http://") || url.startsWith("https://") || url.startsWith("rtsp://")) {
            "Portal did not return a supported stream URL."
        }
        PlaybackSource(url, playbackHeaders())
    }

    private fun playbackHeaders(): Map<String, String> = buildMap {
        put("User-Agent", USER_AGENT)
        put("X-User-Agent", "Model: MAG250; Link: WiFi")
        put("Cookie", "mac=${config.mac}; stb_lang=en; timezone=UTC")
        put("Referer", "${config.baseUrl}/")
        if (token.isNotBlank()) put("Authorization", "Bearer $token")
    }

    private fun call(query: String): JSONObject {
        check(endpointUrl.isNotBlank()) { "Portal endpoint has not been initialized." }
        return request(endpointUrl, query)
    }

    private suspend fun discoverEndpointAndHandshake(): JSONObject = coroutineScope {
        val entered = config.baseUrl.trimEnd('/')
        val withoutPortalPath = entered.replace(
            Regex("(?i)/(c|server/load\\.php|stalker_portal/server/load\\.php|stalker_portal/portal\\.php|portal\\.php)$"),
            ""
        )
        val roots = buildList {
            add(entered)
            add(withoutPortalPath)
            listOf(entered, withoutPortalPath).forEach { value ->
                when {
                    value.startsWith("https://") -> add("http://${value.removePrefix("https://")}")
                    value.startsWith("http://") -> add("https://${value.removePrefix("http://")}")
                }
            }
        }.distinct()
        val candidates = buildList {
            roots.forEach { root ->
                if (root.endsWith(".php", ignoreCase = true)) add(root)
                else {
                    add("$root/server/load.php")
                    add("$root/portal.php")
                    add("$root/stalker_portal/server/load.php")
                    add("$root/stalker_portal/portal.php")
                    add("$root/c/portal.php")
                }
            }
        }.distinct()
        val winner = CompletableDeferred<Pair<String, JSONObject>>()
        val portalRespondedWithoutToken = AtomicBoolean(false)
        val lastError = AtomicReference<Throwable?>(null)
        val jobs = candidates.map { candidate ->
            launch {
                val result = runCatching {
                    request(candidate, "type=stb&action=handshake&token=&JsHttpRequest=1-xml", discoveryHttp)
                }
                val json = result.getOrNull()
                if (json != null && payloadObject(json)?.optString("token").orEmpty().isNotBlank()) {
                    winner.complete(candidate to json)
                } else if (json != null) {
                    portalRespondedWithoutToken.set(true)
                }
                result.exceptionOrNull()?.let(lastError::set)
            }
        }
        val match = withTimeoutOrNull(9_000) { winner.await() }
        jobs.forEach { it.cancel() }
        if (match != null) {
            endpointUrl = match.first
            config = config.copy(baseUrl = portalBase(match.first))
            return@coroutineScope match.second
        }
        if (portalRespondedWithoutToken.get()) {
            throw IllegalArgumentException("Portal found, but this MAC address is not authorized by the provider.")
        }
        throw IllegalArgumentException("Unable to find a compatible authorized portal endpoint.", lastError.get())
    }

    private fun portalBase(endpoint: String): String = endpoint.replace(
        Regex("(?i)/(c/portal\\.php|server/load\\.php|portal\\.php|stalker_portal/server/load\\.php|stalker_portal/portal\\.php)$"),
        ""
    ).trimEnd('/')

    private fun request(endpoint: String, query: String, client: OkHttpClient = http): JSONObject {
        val url = "$endpoint?$query"
        val request = Request.Builder().url(url)
            .header("User-Agent", USER_AGENT)
            .header("X-User-Agent", "Model: MAG250; Link: WiFi")
            .header("Cookie", "mac=${config.mac}; stb_lang=en; timezone=UTC")
            .apply { if (token.isNotBlank()) header("Authorization", "Bearer $token") }
            .build()
        return client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            require(response.isSuccessful) { "Portal returned HTTP ${response.code}." }
            parseObject(body)
        }
    }

    private fun parseObject(body: String): JSONObject {
        val cleaned = body.trim().removePrefix("\uFEFF")
        require(cleaned.isNotBlank()) { "Portal returned an empty response." }
        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')
        require(start >= 0 && end > start) {
            if (cleaned.startsWith("<")) "Portal returned a web page instead of portal data."
            else "Portal returned an unsupported response."
        }
        return try {
            JSONObject(cleaned.substring(start, end + 1))
        } catch (_: JSONException) {
            throw IllegalArgumentException("Portal returned invalid JSON data.")
        }
    }

    private fun payloadObject(root: JSONObject): JSONObject? = when (val value = root.opt("js")) {
        is JSONObject -> value
        is String -> runCatching { JSONObject(value) }.getOrNull()
        else -> null
    }

    private fun payloadArray(root: JSONObject): JSONArray? = when (val value = root.opt("js")) {
        is JSONArray -> value
        is JSONObject -> value.optJSONArray("data")
        is String -> runCatching { JSONArray(value) }.getOrNull()
            ?: runCatching { JSONObject(value).optJSONArray("data") }.getOrNull()
        else -> null
    }

    private fun normalizeBase(value: String): String {
        val raw = value.trim().trimEnd('/')
        return if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "https://$raw"
    }
    private fun normalizeMac(value: String): String {
        val mac = value.trim().replace(';', ':').uppercase()
        require(Regex("^([0-9A-F]{2}:){5}[0-9A-F]{2}$").matches(mac)) { "Enter a valid MAC address." }
        return mac
    }

    private companion object {
        const val USER_AGENT = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3"
    }
}
