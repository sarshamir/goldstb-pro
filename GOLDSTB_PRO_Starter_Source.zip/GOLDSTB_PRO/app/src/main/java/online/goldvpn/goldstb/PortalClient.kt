package online.goldvpn.goldstb

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class PortalClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()
    private var token: String = ""
    private lateinit var config: PortalConfig
    private var endpointUrl: String = ""

    suspend fun connect(input: PortalConfig): Pair<List<Category>, List<Channel>> = withContext(Dispatchers.IO) {
        config = input.copy(baseUrl = normalizeBase(input.baseUrl), mac = normalizeMac(input.mac))
        token = ""
        val handshake = discoverEndpointAndHandshake()
        token = handshake.optJSONObject("js")?.optString("token").orEmpty()
        require(token.isNotBlank()) { "Portal did not return an authorization token." }
        // A profile request completes initialization on many authorized Stalker/MAG portals.
        runCatching { call("type=stb&action=get_profile&JsHttpRequest=1-xml") }
        val categoryJson = call("type=itv&action=get_genres&JsHttpRequest=1-xml")
        val categoriesArray = categoryJson.optJSONArray("js")
        val categories = buildList {
            if (categoriesArray != null) for (i in 0 until categoriesArray.length()) {
                val item = categoriesArray.optJSONObject(i) ?: continue
                add(Category(item.optString("id"), item.optString("title", "Other")))
            }
        }
        val channelJson = call("type=itv&action=get_all_channels&JsHttpRequest=1-xml")
        val channelsArray = channelJson.optJSONObject("js")?.optJSONArray("data")
            ?: channelJson.optJSONArray("js")
        val channels = buildList {
            if (channelsArray != null) for (i in 0 until channelsArray.length()) {
                val item = channelsArray.optJSONObject(i) ?: continue
                val id = item.optString("id")
                val name = item.optString("name", "Channel")
                val cmd = item.optString("cmd")
                if (id.isNotBlank() && cmd.isNotBlank()) add(Channel(id, name, cmd, item.optString("tv_genre_id")))
            }
        }
        categories to channels
    }

    suspend fun resolve(channel: Channel): String = withContext(Dispatchers.IO) {
        val encoded = URLEncoder.encode(channel.command, Charsets.UTF_8.name())
        val json = call("type=itv&action=create_link&cmd=$encoded&series=0&forced_storage=undefined&disable_ad=0&download=0&JsHttpRequest=1-xml")
        val cmd = json.optJSONObject("js")?.optString("cmd").orEmpty()
        val url = cmd.substringAfter(" ", cmd).trim()
        require(url.startsWith("http")) { "Portal did not return a playable stream URL." }
        url
    }

    private fun call(query: String): JSONObject {
        check(endpointUrl.isNotBlank()) { "Portal endpoint has not been initialized." }
        return request(endpointUrl, query)
    }

    private fun discoverEndpointAndHandshake(): JSONObject {
        val base = config.baseUrl
        val candidates = buildList {
            if (base.endsWith(".php", ignoreCase = true)) add(base)
            else {
                add("$base/server/load.php")
                add("$base/stalker_portal/server/load.php")
                add("$base/portal.php")
            }
        }.distinct()
        var lastError: Throwable? = null
        for (candidate in candidates) {
            val result = runCatching {
                request(candidate, "type=stb&action=handshake&token=&JsHttpRequest=1-xml")
            }
            val json = result.getOrNull()
            if (json?.optJSONObject("js")?.optString("token").orEmpty().isNotBlank()) {
                endpointUrl = candidate
                return json
            }
            lastError = result.exceptionOrNull()
        }
        throw IllegalArgumentException("Unable to find a compatible authorized portal endpoint.", lastError)
    }

    private fun request(endpoint: String, query: String): JSONObject {
        val url = "$endpoint?$query"
        val request = Request.Builder().url(url)
            .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3")
            .header("X-User-Agent", "Model: MAG250; Link: WiFi")
            .header("Cookie", "mac=${config.mac}; stb_lang=en; timezone=UTC")
            .apply { if (token.isNotBlank()) header("Authorization", "Bearer $token") }
            .build()
        return http.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            require(response.isSuccessful) { "Portal returned HTTP ${response.code}." }
            JSONObject(body)
        }
    }

    private fun normalizeBase(value: String): String {
        val raw = value.trim().trimEnd('/')
        return if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "https://$raw"
    }
    private fun normalizeMac(value: String): String {
        val mac = value.trim().replace(';', ':').uppercase()
        require(Regex("^([0-9A-F]{2}:){5}[0-9A-F]{2}$").matches(mac)) { "Enter a valid MAC address." }
        return mac
    }
}
