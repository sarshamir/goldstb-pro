package online.goldvpn.goldstb

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

class PortalClient {
    private val cookieJar = object : CookieJar {
        private val cookies = ConcurrentHashMap<String, List<Cookie>>()
        override fun saveFromResponse(url: HttpUrl, newCookies: List<Cookie>) {
            cookies[url.host] = (newCookies + cookies[url.host].orEmpty())
                .distinctBy { "${it.name}|${it.path}" }
        }
        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            val saved = cookies.values.flatten().filter { it.matches(url) }
            val device = listOf(
                Cookie.Builder().name("mac").value(config.mac).hostOnlyDomain(url.host).path("/").build(),
                Cookie.Builder().name("stb_lang").value("en").hostOnlyDomain(url.host).path("/").build(),
                Cookie.Builder().name("timezone").value("UTC").hostOnlyDomain(url.host).path("/").build()
            )
            return (device + saved).distinctBy { "${it.name}|${it.path}" }
        }
    }
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .cookieJar(cookieJar)
        .build()
    private val discoveryHttp = http.newBuilder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(35, TimeUnit.SECONDS)
        .build()
    private var token: String = ""
    private lateinit var config: PortalConfig
    private var endpointUrl: String = ""
    private val vodCache = ConcurrentHashMap<String, List<Channel>>()

    suspend fun connect(input: PortalConfig, progress: (Float, String) -> Unit = { _, _ -> }): PortalContent = withContext(Dispatchers.IO) {
        config = input.copy(baseUrl = normalizeBase(input.baseUrl), mac = normalizeMac(input.mac))
        token = ""
        endpointUrl = ""
        vodCache.clear()
        progress(.12f, "Finding portal…")
        val handshake = discoverEndpointAndHandshake()
        token = payloadObject(handshake)?.optString("token").orEmpty()
        require(token.isNotBlank()) { "Portal did not return an authorization token." }
        progress(.35f, "Authorizing MAC…")
        // A profile request completes initialization on many authorized Stalker/MAG portals.
        val profile = runCatching { call("type=stb&action=get_profile&JsHttpRequest=1-xml") }.getOrNull()
        val profileJs = profile?.let(::payloadObject)
        val blocked = profileJs?.optString("blocked").orEmpty()
        val status = profileJs?.optString("status").orEmpty()
        require(!(blocked == "1" || status.equals("blocked", true) || status.equals("expired", true))) {
            "This subscription is expired or blocked by the provider."
        }
        progress(.55f, "Loading categories…")
        val (categoryJson, channelJson, vodCategoryJson) = coroutineScope {
            listOf(
                async { call("type=itv&action=get_genres&JsHttpRequest=1-xml") },
                async { call("type=itv&action=get_all_channels&JsHttpRequest=1-xml") },
                async { runCatching { call("type=vod&action=get_categories&JsHttpRequest=1-xml") }.getOrElse { JSONObject() } }
            ).awaitAll()
        }
        val categoriesArray = payloadArray(categoryJson)
        val categories = buildList {
            if (categoriesArray != null) for (i in 0 until categoriesArray.length()) {
                val item = categoriesArray.optJSONObject(i) ?: continue
                add(Category(item.optString("id"), item.optString("title", "Other"), MediaKind.LIVE))
            }
        }
        val channelsArray = payloadObject(channelJson)?.optJSONArray("data")
            ?: payloadArray(channelJson)
        val channels = buildList {
            if (channelsArray != null) for (i in 0 until channelsArray.length()) {
                val item = channelsArray.optJSONObject(i) ?: continue
                val id = item.optString("id")
                val name = item.optString("name", "Channel")
                val cmd = item.optString("cmd")
                if (id.isNotBlank() && cmd.isNotBlank()) add(Channel(id, name, cmd, item.optString("tv_genre_id"), MediaKind.LIVE, item.optString("logo")))
            }
        }
        val vodCategories = buildList {
            val array = payloadArray(vodCategoryJson)
            if (array != null) for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val id = item.optString("id")
                if (id.isNotBlank()) add(Category(id, item.optString("title", "Other"), MediaKind.VOD))
            }
        }
        progress(1f, "Ready")
        PortalContent(categories, channels, vodCategories, accountInfo(profileJs))
    }

    fun clearCache() {
        vodCache.clear()
    }

    suspend fun loadVod(categoryId: String?): List<Channel> = withContext(Dispatchers.IO) {
        val cacheKey = categoryId ?: "*"
        vodCache[cacheKey]?.let { return@withContext it }
        val categoryQuery = categoryId?.takeIf { it.isNotBlank() }
            ?.let { "&category=${URLEncoder.encode(it, Charsets.UTF_8.name())}" }
            .orEmpty()
        val json = call("type=vod&action=get_ordered_list${categoryQuery}&p=1&sortby=added&JsHttpRequest=1-xml")
        val array = payloadObject(json)?.optJSONArray("data") ?: payloadArray(json)
        val items = buildList {
            if (array != null) for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val id = item.optString("id")
                val cmd = item.optString("cmd")
                if (id.isNotBlank() && cmd.isNotBlank()) add(
                    Channel(id, item.optString("name", "Movie"), cmd, categoryId.orEmpty(), MediaKind.VOD, item.optString("screenshot_uri"))
                )
            }
        }
        vodCache[cacheKey] = items
        items
    }

    suspend fun resolve(channel: Channel): PlaybackSource = withContext(Dispatchers.IO) {
        val encoded = URLEncoder.encode(channel.command, Charsets.UTF_8.name())
        val type = if (channel.kind == MediaKind.VOD) "vod" else "itv"
        val json = call("type=$type&action=create_link&cmd=$encoded&series=0&forced_storage=undefined&disable_ad=0&download=0&JsHttpRequest=1-xml")
        val cmd = payloadObject(json)?.optString("cmd").orEmpty()
        val url = cmd.substringAfter(" ", cmd).trim()
            .removeSurrounding("\"")
            .removeSurrounding("'")
        require(url.startsWith("http://") || url.startsWith("https://") || url.startsWith("rtsp://")) {
            "Portal did not return a supported stream URL."
        }
        PlaybackSource(url, playbackHeaders())
    }

    private fun playbackHeaders(): Map<String, String> = buildMap {
        put("User-Agent", USER_AGENT)
        put("X-User-Agent", "Model: MAG250; Link: WiFi")
        put("Cookie", "mac=${config.mac}; stb_lang=en; timezone=UTC")
        put("Referer", "${config.baseUrl}/")
        if (token.isNotBlank()) put("Authorization", "Bearer $token")
    }

    private fun call(query: String): JSONObject {
        check(endpointUrl.isNotBlank()) { "Portal endpoint has not been initialized." }
        return request(endpointUrl, query)
    }

    private suspend fun discoverEndpointAndHandshake(): JSONObject = coroutineScope {
        val entered = config.baseUrl.trimEnd('/')
        val withoutPortalPath = entered.replace(
            Regex("(?i)/(c|server/load\\.php|stalker_portal/server/load\\.php|stalker_portal/portal\\.php|portal\\.php)$"),
            ""
        )
        val initialRoots = buildList {
            add(entered)
            add(withoutPortalPath)
            listOf(entered, withoutPortalPath).forEach { value ->
                when {
                    value.startsWith("https://") -> add("http://${value.removePrefix("https://")}")
                    value.startsWith("http://") -> add("https://${value.removePrefix("http://")}")
                }
            }
        }.distinct()
        // Some reseller domains use a web forwarding page instead of a 30x response.
        // Resolve those pages before probing the Stalker endpoints.
        val forwardedRoots = initialRoots.map { root ->
            async { runCatching { followForwardingPage(root) }.getOrDefault(root) }
        }.awaitAll()
        val roots = (forwardedRoots + initialRoots)
            .flatMap(::portalRootVariants)
            .distinct()
        val candidates = buildList {
            roots.forEach { root ->
                if (root.endsWith(".php", ignoreCase = true)) add(root)
                else {
                    add("$root/server/load.php")
                    add("$root/portal.php")
                    add("$root/stalker_portal/server/load.php")
                    add("$root/stalker_portal/portal.php")
                    add("$root/c/portal.php")
                }
            }
        }.distinct()
        val winner = CompletableDeferred<Pair<String, JSONObject>>()
        val portalRespondedWithoutToken = AtomicBoolean(false)
        val lastError = AtomicReference<Throwable?>(null)
        val jobs = candidates.map { candidate ->
            launch {
                val result = runCatching {
                    requestResult(candidate, "type=stb&action=handshake&token=&JsHttpRequest=1-xml", discoveryHttp)
                }
                val response = result.getOrNull()
                val json = response?.first
                if (json != null && payloadObject(json)?.optString("token").orEmpty().isNotBlank()) {
                    winner.complete(response.second to json)
                } else if (json != null) {
                    portalRespondedWithoutToken.set(true)
                }
                result.exceptionOrNull()?.let(lastError::set)
            }
        }
        val match = withTimeoutOrNull(45_000) { winner.await() }
        jobs.forEach { it.cancel() }
        if (match != null) {
            endpointUrl = match.first
            config = config.copy(baseUrl = portalBase(match.first))
            return@coroutineScope match.second
        }
        if (portalRespondedWithoutToken.get()) {
            throw IllegalArgumentException("Portal found, but this MAC address is not authorized by the provider.")
        }
        throw IllegalArgumentException("Unable to find a compatible authorized portal endpoint.", lastError.get())
    }

    private fun portalBase(endpoint: String): String = endpoint.replace(
        Regex("(?i)/(c/portal\\.php|server/load\\.php|portal\\.php|stalker_portal/server/load\\.php|stalker_portal/portal\\.php)$"),
        ""
    ).trimEnd('/')

    private fun request(endpoint: String, query: String, client: OkHttpClient = http): JSONObject {
        return requestResult(endpoint, query, client).first
    }

    private fun requestResult(endpoint: String, query: String, client: OkHttpClient = http): Pair<JSONObject, String> {
        val url = "$endpoint?$query"
        val request = Request.Builder().url(url)
            .header("User-Agent", USER_AGENT)
            .header("X-User-Agent", "Model: MAG250; Link: WiFi")
            .header("Cookie", "mac=${config.mac}; stb_lang=en; timezone=UTC")
            .apply { if (token.isNotBlank()) header("Authorization", "Bearer $token") }
            .build()
        return client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            require(response.isSuccessful) { "Portal returned HTTP ${response.code}." }
            val finalEndpoint = response.request.url.newBuilder().query(null).build().toString().trimEnd('/')
            parseObject(body) to finalEndpoint
        }
    }

    private fun followForwardingPage(start: String): String {
        var current = start
        repeat(6) {
            val request = Request.Builder().url(current)
                .header("User-Agent", USER_AGENT)
                .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                .build()
            discoveryHttp.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return current
                val finalUrl = response.request.url
                val body = response.body?.string().orEmpty()
                val target = forwardingTarget(body)
                    ?: forwardingQueryTarget(finalUrl)
                    ?: return finalUrl.toString().trimEnd('/')
                val resolved = finalUrl.resolve(target) ?: return finalUrl.toString().trimEnd('/')
                val next = resolved.toString().trimEnd('/')
                if (next == current.trimEnd('/')) return next
                current = next
            }
        }
        return current.trimEnd('/')
    }

    private fun forwardingTarget(body: String): String? {
        if (body.isBlank() || body.length > 1_000_000) return null
        val patterns = listOf(
            Regex("(?is)<meta[^>]+content\\s*=\\s*[\\\"'][^\\\"']*url\\s*=\\s*([^\\\"'>; ]+)") ,
            Regex("(?is)(?:window\\.)?location(?:\\.href)?\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']"),
            Regex("(?is)location\\.(?:replace|assign)\\(\\s*[\\\"']([^\\\"']+)[\\\"']"),
            Regex("(?is)<iframe[^>]+src\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']"),
            Regex("(?is)<link[^>]+rel\\s*=\\s*[\\\"']canonical[\\\"'][^>]+href\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']"),
            Regex("(?is)(?:redirect|portal|target|destination|url)\\s*[:=]\\s*[\\\"']((?:https?:)?\\/\\/[^\\\"']+)[\\\"']")
        )
        return patterns.firstNotNullOfOrNull { it.find(body)?.groupValues?.getOrNull(1) }
            ?.replace("&amp;", "&")
            ?.replace("\\/", "/")
            ?.trim()
    }

    private fun forwardingQueryTarget(url: HttpUrl): String? {
        val keys = listOf("url", "target", "redirect", "redirect_url", "destination", "portal")
        return keys.firstNotNullOfOrNull { key ->
            url.queryParameter(key)?.takeIf { it.isNotBlank() }?.let { value ->
                runCatching { URLDecoder.decode(value, Charsets.UTF_8.name()) }.getOrDefault(value)
            }
        }?.takeIf { it.startsWith("http://", true) || it.startsWith("https://", true) }
    }

    private fun portalRootVariants(value: String): List<String> {
        val clean = value.substringBefore('#').substringBefore('?').trimEnd('/')
        val parsed = clean.toHttpUrlOrNull() ?: return listOf(clean)
        val origin = parsed.newBuilder().encodedPath("/").query(null).fragment(null).build().toString().trimEnd('/')
        val withoutPage = clean.replace(Regex("(?i)/(?:index|home|redirect|forward)?\\.(?:php|html?)$"), "")
        val withoutPortalEntry = withoutPage.replace(Regex("(?i)/(?:c|stalker_portal/c)$"), "")
        return listOf(clean, withoutPage, withoutPortalEntry, origin).filter { it.isNotBlank() }.distinct()
    }

    private fun accountInfo(profile: JSONObject?): AccountInfo {
        if (profile == null) return AccountInfo()
        fun first(vararg keys: String): String = keys.firstNotNullOfOrNull { key ->
            profile.opt(key)?.toString()?.trim()?.takeUnless { it.isBlank() || it.equals("null", true) }
        }.orEmpty()
        return AccountInfo(
            username = first("name", "username", "login", "account_name", "fname"),
            status = first("status", "account_status", "blocked"),
            expires = first("expire_billing_date", "expires", "expiration", "end_date"),
            plan = first("tariff_plan", "tariff_plan_name", "plan", "package"),
            server = first("server", "server_name", "portal")
        )
    }

    private fun parseObject(body: String): JSONObject {
        val cleaned = body.trim().removePrefix("\uFEFF")
        require(cleaned.isNotBlank()) { "Portal returned an empty response." }
        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')
        require(start >= 0 && end > start) {
            if (cleaned.startsWith("<")) "Portal returned a web page instead of portal data."
            else "Portal returned an unsupported response."
        }
        return try {
            JSONObject(cleaned.substring(start, end + 1))
        } catch (_: JSONException) {
            throw IllegalArgumentException("Portal returned invalid JSON data.")
        }
    }

    private fun payloadObject(root: JSONObject): JSONObject? = when (val value = root.opt("js")) {
        is JSONObject -> value
        is String -> runCatching { JSONObject(value) }.getOrNull()
        else -> null
    }

    private fun payloadArray(root: JSONObject): JSONArray? = when (val value = root.opt("js")) {
        is JSONArray -> value
        is JSONObject -> value.optJSONArray("data")
        is String -> runCatching { JSONArray(value) }.getOrNull()
            ?: runCatching { JSONObject(value).optJSONArray("data") }.getOrNull()
        else -> null
    }

    private fun normalizeBase(value: String): String {
        val raw = value.trim().trimEnd('/')
        return if (raw.startsWith("http://", true) || raw.startsWith("https://", true)) raw else "https://$raw"
    }
    private fun normalizeMac(value: String): String {
        val mac = value.trim().replace(';', ':').uppercase()
        require(Regex("^([0-9A-F]{2}:){5}[0-9A-F]{2}$").matches(mac)) { "Enter a valid MAC address." }
        return mac
    }

    private companion object {
        const val USER_AGENT = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3"
    }
}
