package online.goldvpn.goldstb

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import java.security.SecureRandom
import org.json.JSONArray

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val portal = PortalClient()
    private val prefs = app.getSharedPreferences("goldstb", 0)
    private val savedConfig = loadConfig()
    private var vodLoadJob: Job? = null
    var state = androidx.compose.runtime.mutableStateOf(
        AppState(
            config = savedConfig ?: PortalConfig("", loadOrCreateMac()),
            favorites = prefs.getStringSet("favorites", emptySet()) ?: emptySet(),
            recentChannelIds = prefs.getString("recent", "").orEmpty().split(',').filter { it.isNotBlank() }
        )
    )
        private set

    init {
        if (savedConfig != null) connect(savedConfig.baseUrl, savedConfig.mac)
    }

    fun connect(url: String, mac: String) = viewModelScope.launch {
        val config = PortalConfig(url.trim(), mac.trim().replace(';', ':').uppercase())
        saveConfig(config)
        state.value = state.value.copy(config = config, settingsMessage = "Portal and MAC saved.")
        if (!isOnline()) {
            state.value = state.value.copy(
                busy = false,
                config = config,
                screen = Screen.ConnectionError(ConnectionProblem.NO_INTERNET, NO_INTERNET_MESSAGE)
            )
            return@launch
        }
        state.value = state.value.copy(busy = true, loadingProgress = .05f, error = null, connectionLabel = "Connecting…")
        runCatching {
            portal.connect(config) { amount, label ->
                state.value = state.value.copy(loadingProgress = amount, connectionLabel = label)
            }
        }
            .onSuccess { content ->
                state.value = state.value.copy(
                    busy = false,
                    loadingProgress = 1f,
                    screen = Screen.Library,
                    config = config,
                    liveCategories = content.liveCategories,
                    liveChannels = content.liveChannels,
                    vodCategories = content.vodCategories,
                    selectedCategory = null,
                    selectedKind = MediaKind.LIVE,
                    connectionLabel = "Connected",
                    accountInfo = content.accountInfo
                )
            }
            .onFailure { error ->
                val message = error.message ?: "Unable to connect."
                val type = when {
                    message.contains("expired", true) || message.contains("blocked", true) -> ConnectionProblem.EXPIRED_OR_BLOCKED
                    message.contains("not authorized", true) || message.contains("authorization token", true) -> ConnectionProblem.NOT_AUTHORIZED
                    message.contains("invalid JSON", true) || message.contains("unsupported response", true) -> ConnectionProblem.INVALID_RESPONSE
                    message.contains("endpoint", true) || message.contains("web page", true) -> ConnectionProblem.PORTAL_NOT_FOUND
                    !isOnline() -> ConnectionProblem.NO_INTERNET
                    else -> ConnectionProblem.NETWORK
                }
                state.value = state.value.copy(
                    busy = false,
                    connectionLabel = null,
                    screen = Screen.ConnectionError(type, if (type == ConnectionProblem.NO_INTERNET) NO_INTERNET_MESSAGE else message)
                )
            }
    }

    fun selectSection(kind: MediaKind) {
        state.value = state.value.copy(selectedKind = kind, selectedCategory = null, selectedCategoryTitle = "All", query = "")
    }
    fun openCategory(category: Category?) = viewModelScope.launch {
        val requestedKind = category?.kind ?: state.value.selectedKind
        if (!isOnline() && requestedKind == MediaKind.VOD) {
            state.value = state.value.copy(screen = Screen.ConnectionError(ConnectionProblem.NO_INTERNET, NO_INTERNET_MESSAGE))
            return@launch
        }
        val kind = requestedKind
        state.value = state.value.copy(selectedKind = kind, selectedCategory = category?.id, selectedCategoryTitle = category?.title ?: "All", query = "")
        if (kind == MediaKind.VOD && category?.id != "__favorites") {
            vodLoadJob?.cancel()
            vodLoadJob = coroutineContext[Job]
            state.value = state.value.copy(busy = true, loadingProgress = .4f, connectionLabel = "Loading VOD…")
            runCatching { portal.loadVod(category?.id) }
                .onSuccess { state.value = state.value.copy(busy = false, loadingProgress = 1f, vodItems = it, screen = Screen.Content, connectionLabel = null) }
                .onFailure {
                    if (it is CancellationException) return@onFailure
                    val problem = if (!isOnline()) ConnectionProblem.NO_INTERNET else ConnectionProblem.INVALID_RESPONSE
                    val message = if (problem == ConnectionProblem.NO_INTERNET) NO_INTERNET_MESSAGE else it.message ?: "Unable to load VOD."
                    state.value = state.value.copy(busy = false, screen = Screen.ConnectionError(problem, message))
                }
        } else {
            state.value = state.value.copy(screen = Screen.Content)
        }
    }
    fun backToLibrary() { state.value = state.value.copy(screen = Screen.Library, query = "") }
    fun play(channel: Channel) = viewModelScope.launch {
        if (!isOnline()) {
            state.value = state.value.copy(screen = Screen.ConnectionError(ConnectionProblem.NO_INTERNET, NO_INTERNET_MESSAGE))
            return@launch
        }
        state.value = state.value.copy(busy = true, error = null)
        runCatching { portal.resolve(channel) }
            .onSuccess {
                val recent = (listOf(channel.id) + state.value.recentChannelIds).distinct().take(20)
                prefs.edit().putString("recent", recent.joinToString(",")).apply()
                state.value = state.value.copy(busy = false, recentChannelIds = recent, screen = Screen.Player(channel, it))
            }
            .onFailure { state.value = state.value.copy(busy = false, error = it.message ?: "Unable to play channel.") }
    }
    fun backToChannels() { state.value = state.value.copy(screen = Screen.Content) }
    fun retry() { state.value.config?.let { connect(it.baseUrl, it.mac) } }
    fun editPortal() { state.value = state.value.copy(screen = Screen.Setup, busy = false, error = null) }
    fun clearCache() {
        vodLoadJob?.cancel()
        portal.clearCache()
        state.value = state.value.copy(vodItems = emptyList(), query = "", settingsMessage = "Cache cleared. Your portal and MAC address were kept.")
    }
    fun disconnect() {
        state.value = AppState(config = loadConfig(), favorites = state.value.favorites, recentChannelIds = state.value.recentChannelIds)
    }
    fun search(value: String) { state.value = state.value.copy(query = value) }
    fun toggleFavorite(id: String) {
        val next = state.value.favorites.toMutableSet().apply { if (!add(id)) remove(id) }
        prefs.edit().putStringSet("favorites", next).apply()
        state.value = state.value.copy(favorites = next)
    }

    private fun saveConfig(config: PortalConfig) {
        prefs.edit().putString("portal_url", config.baseUrl).putString("portal_mac", config.mac).apply()
    }
    private fun loadConfig(): PortalConfig? {
        val url = prefs.getString("portal_url", "").orEmpty()
        val mac = prefs.getString("portal_mac", "").orEmpty()
        if (url.isNotBlank() && mac.isNotBlank()) return PortalConfig(url, mac)
        return runCatching {
            val previousProfiles = JSONArray(prefs.getString("profiles", "[]"))
            if (previousProfiles.length() == 0) null else {
                val first = previousProfiles.getJSONObject(0)
                PortalConfig(first.getString("url"), first.getString("mac")).also(::saveConfig)
            }
        }.getOrNull()
    }

    private fun loadOrCreateMac(): String {
        prefs.getString("generated_mac", null)?.takeIf { it.isNotBlank() }?.let { return it }
        val random = SecureRandom()
        val mac = buildList {
            addAll(listOf(0x00, 0x1A, 0x79))
            repeat(3) { add(random.nextInt(256)) }
        }.joinToString(":") { "%02X".format(it) }
        prefs.edit().putString("generated_mac", mac).apply()
        return mac
    }

    private fun isOnline(): Boolean {
        val manager = getApplication<Application>().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = manager.activeNetwork ?: return false
        val capabilities = manager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private companion object {
        const val NO_INTERNET_MESSAGE = "No internet connection. Please check your network and try again."
    }
}
