package online.goldvpn.goldstb

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.security.SecureRandom

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val portal = PortalClient()
    private val prefs = app.getSharedPreferences("goldstb", 0)
    private val savedConfig = loadConfig()
    private var loadJob: Job? = null
    var state = androidx.compose.runtime.mutableStateOf(
        AppState(
            config = savedConfig ?: PortalConfig("", loadOrCreateMac()),
            favorites = prefs.getStringSet("favorites", emptySet()) ?: emptySet(),
            recentChannelIds = prefs.getString("recent", "").orEmpty().split(',').filter(String::isNotBlank)
        )
    )
        private set

    init { if (savedConfig != null) connect(savedConfig, openChannels = true) }

    fun connect(config: PortalConfig, openChannels: Boolean = false) = viewModelScope.launch {
        val cleaned = config.copy(baseUrl = config.baseUrl.trim(), mac = config.mac.trim().replace(';', ':').uppercase(), username = config.username.trim())
        saveConfig(cleaned)
        state.value = state.value.copy(config = cleaned, settingsMessage = "Connection settings saved.")
        if (!isOnline()) {
            state.value = state.value.copy(busy = false, screen = Screen.ConnectionError(ConnectionProblem.NO_INTERNET, NO_INTERNET_MESSAGE))
            return@launch
        }
        state.value = state.value.copy(busy = true, loadingProgress = .05f, error = null, connectionLabel = "Connecting…")
        runCatching { portal.connect(cleaned) { amount, label -> state.value = state.value.copy(loadingProgress = amount, connectionLabel = label) } }
            .onSuccess { content ->
                state.value = state.value.copy(
                    busy = false, loadingProgress = 1f, screen = if (openChannels) Screen.Content else Screen.Library,
                    config = cleaned, liveCategories = content.liveCategories, liveChannels = content.liveChannels,
                    vodCategories = content.vodCategories, seriesCategories = content.seriesCategories,
                    selectedCategory = null, selectedKind = MediaKind.LIVE, connectionLabel = "Connected", accountInfo = content.accountInfo
                )
            }
            .onFailure { error ->
                val message = error.message ?: "Unable to connect."
                val type = when {
                    message.contains("expired", true) || message.contains("blocked", true) || message.contains("inactive", true) -> ConnectionProblem.EXPIRED_OR_BLOCKED
                    message.contains("not authorized", true) || message.contains("authorization token", true) -> ConnectionProblem.NOT_AUTHORIZED
                    message.contains("invalid JSON", true) || message.contains("unsupported response", true) -> ConnectionProblem.INVALID_RESPONSE
                    message.contains("endpoint", true) || message.contains("web page", true) -> ConnectionProblem.PORTAL_NOT_FOUND
                    !isOnline() -> ConnectionProblem.NO_INTERNET
                    else -> ConnectionProblem.NETWORK
                }
                state.value = state.value.copy(busy = false, connectionLabel = null, screen = Screen.ConnectionError(type, if (type == ConnectionProblem.NO_INTERNET) NO_INTERNET_MESSAGE else message))
            }
    }

    fun selectSection(kind: MediaKind) { state.value = state.value.copy(selectedKind = kind, selectedCategory = null, selectedCategoryTitle = "All", query = "") }

    fun openCategory(category: Category?) = viewModelScope.launch {
        val kind = category?.kind ?: state.value.selectedKind
        state.value = state.value.copy(selectedKind = kind, selectedCategory = category?.id, selectedCategoryTitle = category?.title ?: "All", query = "")
        if (kind == MediaKind.LIVE || category?.id == FAVORITES) {
            state.value = state.value.copy(screen = Screen.Content)
            return@launch
        }
        if (!isOnline()) { state.value = state.value.copy(screen = Screen.ConnectionError(ConnectionProblem.NO_INTERNET, NO_INTERNET_MESSAGE)); return@launch }
        loadJob?.cancel(); loadJob = coroutineContext[Job]
        state.value = state.value.copy(busy = true, loadingProgress = .4f, connectionLabel = if (kind == MediaKind.SERIES) "Loading series…" else "Loading movies…")
        runCatching { portal.loadItems(kind, category?.id) }
            .onSuccess { items -> state.value = if (kind == MediaKind.SERIES) state.value.copy(busy = false, seriesItems = items, screen = Screen.Content, connectionLabel = null) else state.value.copy(busy = false, vodItems = items, screen = Screen.Content, connectionLabel = null) }
            .onFailure { error ->
                if (error is CancellationException) return@onFailure
                val noInternet = !isOnline()
                state.value = state.value.copy(busy = false, screen = Screen.ConnectionError(if (noInternet) ConnectionProblem.NO_INTERNET else ConnectionProblem.INVALID_RESPONSE, if (noInternet) NO_INTERNET_MESSAGE else error.message ?: "Unable to load content."))
            }
    }

    fun openItem(item: Channel) { if (item.isContainer || (item.kind == MediaKind.SERIES && item.command.isBlank())) openSeries(item) else play(item) }

    private fun openSeries(series: Channel) = viewModelScope.launch {
        if (!isOnline()) { state.value = state.value.copy(screen = Screen.ConnectionError(ConnectionProblem.NO_INTERNET, NO_INTERNET_MESSAGE)); return@launch }
        state.value = state.value.copy(busy = true, loadingProgress = .5f, connectionLabel = "Loading episodes…", selectedSeriesTitle = series.name)
        runCatching { portal.loadEpisodes(series) }
            .onSuccess { episodes ->
                state.value = state.value.copy(busy = false, connectionLabel = null, episodeItems = episodes, query = "", screen = Screen.Episodes,
                    error = if (episodes.isEmpty()) "No episodes were returned by this portal." else null)
            }
            .onFailure { state.value = state.value.copy(busy = false, connectionLabel = null, screen = Screen.Content, error = it.message ?: "Unable to load episodes.") }
    }

    fun play(channel: Channel) = viewModelScope.launch {
        if (!isOnline()) { state.value = state.value.copy(screen = Screen.ConnectionError(ConnectionProblem.NO_INTERNET, NO_INTERNET_MESSAGE)); return@launch }
        state.value = state.value.copy(busy = false, resolvingChannel = channel, error = null)
        runCatching { portal.resolve(channel) }
            .onSuccess {
                val recent = (listOf(channel.id) + state.value.recentChannelIds).distinct().take(20)
                prefs.edit().putString("recent", recent.joinToString(",")).apply()
                state.value = state.value.copy(resolvingChannel = null, recentChannelIds = recent, screen = Screen.Player(channel, it))
            }
            .onFailure { state.value = state.value.copy(resolvingChannel = null, error = it.message ?: "Unable to play stream.") }
    }

    fun backToLibrary() { state.value = state.value.copy(screen = Screen.Library, query = "", error = null) }
    fun backToSeries() { state.value = state.value.copy(screen = Screen.Content, query = "", error = null) }
    fun backToChannels() { state.value = state.value.copy(screen = if (state.value.selectedKind == MediaKind.SERIES && state.value.episodeItems.isNotEmpty()) Screen.Episodes else Screen.Content) }
    fun retry() { state.value.config?.let { connect(it) } }
    fun editPortal() { state.value = state.value.copy(screen = Screen.Setup, busy = false, error = null) }
    fun clearCache() {
        loadJob?.cancel(); portal.clearCache()
        state.value = state.value.copy(vodItems = emptyList(), seriesItems = emptyList(), episodeItems = emptyList(), query = "", settingsMessage = "Cache cleared. Your connection settings were kept.")
    }
    fun search(value: String) { state.value = state.value.copy(query = value) }
    fun toggleFavorite(id: String) {
        val next = state.value.favorites.toMutableSet().apply { if (!add(id)) remove(id) }
        prefs.edit().putStringSet("favorites", next).apply(); state.value = state.value.copy(favorites = next)
    }

    private fun saveConfig(config: PortalConfig) {
        prefs.edit().putString("portal_url", config.baseUrl).putString("portal_mac", config.mac)
            .putString("portal_type", config.type.name).putString("xtream_username", config.username).putString("xtream_password", config.password).apply()
    }
    private fun loadConfig(): PortalConfig? {
        val url = prefs.getString("portal_url", "").orEmpty(); val mac = prefs.getString("portal_mac", "").orEmpty()
        if (url.isNotBlank()) {
            val type = runCatching { PortalType.valueOf(prefs.getString("portal_type", PortalType.STALKER.name).orEmpty()) }.getOrDefault(PortalType.STALKER)
            val config = PortalConfig(url, mac.ifBlank(::loadOrCreateMac), type, prefs.getString("xtream_username", "").orEmpty(), prefs.getString("xtream_password", "").orEmpty())
            if (type == PortalType.XTREAM && (config.username.isBlank() || config.password.isBlank())) return null
            if (type == PortalType.STALKER && config.mac.isBlank()) return null
            return config
        }
        return runCatching {
            val old = JSONArray(prefs.getString("profiles", "[]")); if (old.length() == 0) null else old.getJSONObject(0).let { PortalConfig(it.getString("url"), it.getString("mac")).also(::saveConfig) }
        }.getOrNull()
    }
    private fun loadOrCreateMac(): String {
        prefs.getString("generated_mac", null)?.takeIf(String::isNotBlank)?.let { return it }
        val random = SecureRandom(); val mac = (listOf(0x00, 0x1A, 0x79) + List(3) { random.nextInt(256) }).joinToString(":") { "%02X".format(it) }
        prefs.edit().putString("generated_mac", mac).apply(); return mac
    }
    private fun isOnline(): Boolean {
        val manager = getApplication<Application>().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = manager.activeNetwork ?: return false; val capabilities = manager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
    private companion object {
        const val FAVORITES = "__favorites"
        const val NO_INTERNET_MESSAGE = "No internet connection. Please check your network and try again."
    }
}
