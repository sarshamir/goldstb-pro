package online.goldvpn.goldstb

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import org.json.JSONArray

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val portal = PortalClient()
    private val prefs = app.getSharedPreferences("goldstb", 0)
    private val savedConfig = loadConfig()
    var state = androidx.compose.runtime.mutableStateOf(
        AppState(
            config = savedConfig,
            favorites = prefs.getStringSet("favorites", emptySet()) ?: emptySet(),
            recentChannelIds = prefs.getString("recent", "").orEmpty().split(',').filter { it.isNotBlank() }
        )
    )
        private set

    init {
        if (savedConfig != null) connect(savedConfig.baseUrl, savedConfig.mac)
    }

    fun connect(url: String, mac: String) = viewModelScope.launch {
        val cleanUrl = url.trim()
            .removePrefix("https://")
            .removePrefix("http://")
        val config = PortalConfig(cleanUrl, mac.trim().replace(';', ':').uppercase())
        saveConfig(config)
        state.value = state.value.copy(busy = true, error = null, connectionLabel = "Connecting…")
        runCatching { portal.connect(config) }
            .onSuccess { (categories, channels) ->
                state.value = state.value.copy(busy = false, screen = Screen.Channels, config = config, categories = categories, channels = channels, selectedCategory = null, connectionLabel = "Connected")
            }
            .onFailure { state.value = state.value.copy(busy = false, connectionLabel = null, error = it.message ?: "Unable to connect.") }
    }

    fun selectCategory(id: String?) { state.value = state.value.copy(selectedCategory = id) }
    fun play(channel: Channel) = viewModelScope.launch {
        state.value = state.value.copy(busy = true, error = null)
        runCatching { portal.resolve(channel) }
            .onSuccess {
                val recent = (listOf(channel.id) + state.value.recentChannelIds).distinct().take(20)
                prefs.edit().putString("recent", recent.joinToString(",")).apply()
                state.value = state.value.copy(busy = false, recentChannelIds = recent, screen = Screen.Player(channel, it))
            }
            .onFailure { state.value = state.value.copy(busy = false, error = it.message ?: "Unable to play channel.") }
    }
    fun backToChannels() { state.value = state.value.copy(screen = Screen.Channels) }
    fun disconnect() {
        state.value = AppState(config = loadConfig(), favorites = state.value.favorites, recentChannelIds = state.value.recentChannelIds)
    }
    fun search(value: String) { state.value = state.value.copy(query = value) }
    fun toggleFavorite(id: String) {
        val next = state.value.favorites.toMutableSet().apply { if (!add(id)) remove(id) }
        prefs.edit().putStringSet("favorites", next).apply()
        state.value = state.value.copy(favorites = next)
    }

    private fun saveConfig(config: PortalConfig) {
        prefs.edit().putString("portal_url", config.baseUrl).putString("portal_mac", config.mac).apply()
    }
    private fun loadConfig(): PortalConfig? {
        val url = prefs.getString("portal_url", "").orEmpty()
        val mac = prefs.getString("portal_mac", "").orEmpty()
        if (url.isNotBlank() && mac.isNotBlank()) return PortalConfig(url, mac)
        return runCatching {
            val previousProfiles = JSONArray(prefs.getString("profiles", "[]"))
            if (previousProfiles.length() == 0) null else {
                val first = previousProfiles.getJSONObject(0)
                PortalConfig(first.getString("url"), first.getString("mac")).also(::saveConfig)
            }
        }.getOrNull()
    }
}
