package online.goldvpn.goldstb

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import java.security.SecureRandom
import org.json.JSONArray

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val portal = PortalClient()
    private val prefs = app.getSharedPreferences("goldstb", 0)
    private val savedConfig = loadConfig()
    private var vodLoadJob: Job? = null
    var state = androidx.compose.runtime.mutableStateOf(
        AppState(
            config = savedConfig ?: PortalConfig("", loadOrCreateMac()),
            favorites = prefs.getStringSet("favorites", emptySet()) ?: emptySet(),
            recentChannelIds = prefs.getString("recent", "").orEmpty().split(',').filter { it.isNotBlank() }
        )
    )
        private set

    init {
        if (savedConfig != null) connect(savedConfig.baseUrl, savedConfig.mac)
    }

    fun connect(url: String, mac: String) = viewModelScope.launch {
        val config = PortalConfig(url.trim(), mac.trim().replace(';', ':').uppercase())
        saveConfig(config)
        state.value = state.value.copy(busy = true, loadingProgress = .05f, error = null, connectionLabel = "Connecting…")
        runCatching {
            portal.connect(config) { amount, label ->
                state.value = state.value.copy(loadingProgress = amount, connectionLabel = label)
            }
        }
            .onSuccess { content ->
                state.value = state.value.copy(
                    busy = false,
                    loadingProgress = 1f,
                    screen = Screen.Library,
                    config = config,
                    liveCategories = content.liveCategories,
                    liveChannels = content.liveChannels,
                    vodCategories = content.vodCategories,
                    selectedCategory = null,
                    selectedKind = MediaKind.LIVE,
                    connectionLabel = "Connected"
                )
            }
            .onFailure { error ->
                val message = error.message ?: "Unable to connect."
                val type = when {
                    message.contains("expired", true) || message.contains("blocked", true) -> ConnectionProblem.EXPIRED_OR_BLOCKED
                    message.contains("not authorized", true) || message.contains("authorization token", true) -> ConnectionProblem.NOT_AUTHORIZED
                    message.contains("invalid JSON", true) || message.contains("unsupported response", true) -> ConnectionProblem.INVALID_RESPONSE
                    message.contains("endpoint", true) || message.contains("web page", true) -> ConnectionProblem.PORTAL_NOT_FOUND
                    else -> ConnectionProblem.NETWORK
                }
                state.value = state.value.copy(busy = false, connectionLabel = null, screen = Screen.ConnectionError(type, message))
            }
    }

    fun selectSection(kind: MediaKind) {
        state.value = state.value.copy(selectedKind = kind, selectedCategory = null, selectedCategoryTitle = "All", query = "")
    }
    fun openCategory(category: Category?) = viewModelScope.launch {
        val kind = category?.kind ?: state.value.selectedKind
        state.value = state.value.copy(selectedKind = kind, selectedCategory = category?.id, selectedCategoryTitle = category?.title ?: "All", query = "")
        if (kind == MediaKind.VOD && category?.id != "__favorites") {
            vodLoadJob?.cancel()
            vodLoadJob = this
            state.value = state.value.copy(busy = true, loadingProgress = .4f, connectionLabel = "Loading VOD…")
            runCatching { portal.loadVod(category?.id) }
                .onSuccess { state.value = state.value.copy(busy = false, loadingProgress = 1f, vodItems = it, screen = Screen.Content, connectionLabel = null) }
                .onFailure { state.value = state.value.copy(busy = false, screen = Screen.ConnectionError(ConnectionProblem.INVALID_RESPONSE, it.message ?: "Unable to load VOD.")) }
        } else {
            state.value = state.value.copy(screen = Screen.Content)
        }
    }
    fun backToLibrary() { state.value = state.value.copy(screen = Screen.Library, query = "") }
    fun play(channel: Channel) = viewModelScope.launch {
        state.value = state.value.copy(busy = true, error = null)
        runCatching { portal.resolve(channel) }
            .onSuccess {
                val recent = (listOf(channel.id) + state.value.recentChannelIds).distinct().take(20)
                prefs.edit().putString("recent", recent.joinToString(",")).apply()
                state.value = state.value.copy(busy = false, recentChannelIds = recent, screen = Screen.Player(channel, it))
            }
            .onFailure { state.value = state.value.copy(busy = false, error = it.message ?: "Unable to play channel.") }
    }
    fun backToChannels() { state.value = state.value.copy(screen = Screen.Content) }
    fun retry() { state.value.config?.let { connect(it.baseUrl, it.mac) } }
    fun editPortal() { state.value = state.value.copy(screen = Screen.Setup, busy = false, error = null) }
    fun disconnect() {
        state.value = AppState(config = loadConfig(), favorites = state.value.favorites, recentChannelIds = state.value.recentChannelIds)
    }
    fun search(value: String) { state.value = state.value.copy(query = value) }
    fun toggleFavorite(id: String) {
        val next = state.value.favorites.toMutableSet().apply { if (!add(id)) remove(id) }
        prefs.edit().putStringSet("favorites", next).apply()
        state.value = state.value.copy(favorites = next)
    }

    private fun saveConfig(config: PortalConfig) {
        prefs.edit().putString("portal_url", config.baseUrl).putString("portal_mac", config.mac).apply()
    }
    private fun loadConfig(): PortalConfig? {
        val url = prefs.getString("portal_url", "").orEmpty()
        val mac = prefs.getString("portal_mac", "").orEmpty()
        if (url.isNotBlank() && mac.isNotBlank()) return PortalConfig(url, mac)
        return runCatching {
            val previousProfiles = JSONArray(prefs.getString("profiles", "[]"))
            if (previousProfiles.length() == 0) null else {
                val first = previousProfiles.getJSONObject(0)
                PortalConfig(first.getString("url"), first.getString("mac")).also(::saveConfig)
            }
        }.getOrNull()
    }

    private fun loadOrCreateMac(): String {
        prefs.getString("generated_mac", null)?.takeIf { it.isNotBlank() }?.let { return it }
        val random = SecureRandom()
        val mac = buildList {
            addAll(listOf(0x00, 0x1A, 0x79))
            repeat(3) { add(random.nextInt(256)) }
        }.joinToString(":") { "%02X".format(it) }
        prefs.edit().putString("generated_mac", mac).apply()
        return mac
    }
}
