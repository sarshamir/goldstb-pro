package online.goldvpn.goldstb

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val portal = PortalClient()
    private val prefs = app.getSharedPreferences("goldstb", 0)
    var state = androidx.compose.runtime.mutableStateOf(
        AppState(
            favorites = prefs.getStringSet("favorites", emptySet()) ?: emptySet(),
            recentChannelIds = prefs.getString("recent", "").orEmpty().split(',').filter { it.isNotBlank() },
            savedProfiles = loadProfiles()
        )
    )
        private set

    fun connect(name: String, url: String, mac: String, rememberProfile: Boolean) = viewModelScope.launch {
        val config = PortalConfig(url.trim(), mac.trim(), name.trim().ifBlank { "My portal" })
        state.value = state.value.copy(busy = true, error = null, connectionLabel = "Connecting…")
        runCatching { portal.connect(config) }
            .onSuccess { (categories, channels) ->
                if (rememberProfile) saveProfile(config)
                state.value = state.value.copy(busy = false, screen = Screen.Channels, config = config, categories = categories, channels = channels, selectedCategory = null, savedProfiles = loadProfiles(), connectionLabel = "Connected")
            }
            .onFailure { state.value = state.value.copy(busy = false, connectionLabel = null, error = it.message ?: "Unable to connect.") }
    }

    fun selectCategory(id: String?) { state.value = state.value.copy(selectedCategory = id) }
    fun play(channel: Channel) = viewModelScope.launch {
        state.value = state.value.copy(busy = true, error = null)
        runCatching { portal.resolve(channel) }
            .onSuccess {
                val recent = (listOf(channel.id) + state.value.recentChannelIds).distinct().take(20)
                prefs.edit().putString("recent", recent.joinToString(",")).apply()
                state.value = state.value.copy(busy = false, recentChannelIds = recent, screen = Screen.Player(channel, it))
            }
            .onFailure { state.value = state.value.copy(busy = false, error = it.message ?: "Unable to play channel.") }
    }
    fun backToChannels() { state.value = state.value.copy(screen = Screen.Channels) }
    fun disconnect() { state.value = AppState(favorites = state.value.favorites, recentChannelIds = state.value.recentChannelIds, savedProfiles = loadProfiles()) }
    fun search(value: String) { state.value = state.value.copy(query = value) }
    fun deleteProfile(profile: PortalConfig) {
        val next = loadProfiles().filterNot { it.baseUrl == profile.baseUrl && it.mac.equals(profile.mac, true) }
        persistProfiles(next)
        state.value = state.value.copy(savedProfiles = next)
    }
    fun toggleFavorite(id: String) {
        val next = state.value.favorites.toMutableSet().apply { if (!add(id)) remove(id) }
        prefs.edit().putStringSet("favorites", next).apply()
        state.value = state.value.copy(favorites = next)
    }

    private fun saveProfile(profile: PortalConfig) {
        val next = (listOf(profile) + loadProfiles().filterNot { it.baseUrl == profile.baseUrl && it.mac.equals(profile.mac, true) }).take(10)
        persistProfiles(next)
    }
    private fun persistProfiles(profiles: List<PortalConfig>) {
        val array = JSONArray()
        profiles.forEach { array.put(JSONObject().put("name", it.name).put("url", it.baseUrl).put("mac", it.mac)) }
        prefs.edit().putString("profiles", array.toString()).apply()
    }
    private fun loadProfiles(): List<PortalConfig> = runCatching {
        val array = JSONArray(prefs.getString("profiles", "[]"))
        (0 until array.length()).map { i ->
            val item = array.getJSONObject(i)
            PortalConfig(item.getString("url"), item.getString("mac"), item.optString("name", "My portal"))
        }
    }.getOrDefault(emptyList())
}
