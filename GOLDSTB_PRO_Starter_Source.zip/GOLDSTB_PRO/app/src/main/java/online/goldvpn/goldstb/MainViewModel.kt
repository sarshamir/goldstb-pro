package online.goldvpn.goldstb

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val portal = PortalClient()
    private val prefs = app.getSharedPreferences("goldstb", 0)
    var state = androidx.compose.runtime.mutableStateOf(AppState(favorites = prefs.getStringSet("favorites", emptySet()) ?: emptySet()))
        private set

    fun connect(url: String, mac: String) = viewModelScope.launch {
        state.value = state.value.copy(busy = true, error = null)
        runCatching { portal.connect(PortalConfig(url, mac)) }
            .onSuccess { (categories, channels) ->
                state.value = state.value.copy(busy = false, screen = Screen.Channels, config = PortalConfig(url, mac), categories = categories, channels = channels, selectedCategory = categories.firstOrNull()?.id)
            }
            .onFailure { state.value = state.value.copy(busy = false, error = it.message ?: "Unable to connect.") }
    }

    fun selectCategory(id: String?) { state.value = state.value.copy(selectedCategory = id) }
    fun play(channel: Channel) = viewModelScope.launch {
        state.value = state.value.copy(busy = true, error = null)
        runCatching { portal.resolve(channel) }
            .onSuccess { state.value = state.value.copy(busy = false, screen = Screen.Player(channel, it)) }
            .onFailure { state.value = state.value.copy(busy = false, error = it.message ?: "Unable to play channel.") }
    }
    fun backToChannels() { state.value = state.value.copy(screen = Screen.Channels) }
    fun disconnect() { state.value = AppState(favorites = state.value.favorites) }
    fun toggleFavorite(id: String) {
        val next = state.value.favorites.toMutableSet().apply { if (!add(id)) remove(id) }
        prefs.edit().putStringSet("favorites", next).apply()
        state.value = state.value.copy(favorites = next)
    }
}
