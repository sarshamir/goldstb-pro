package online.goldvpn.goldstb

import android.os.Bundle
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private val Gold = Color(0xFFF5B700)
private val Dark = Color(0xFF090909)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoldStbTheme { GoldStbApp() } }
    }
}

@Composable private fun GoldStbTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Dark, surface = Color(0xFF171717)), content = content)
}

@Composable private fun GoldStbApp(vm: MainViewModel = viewModel()) {
    val state by vm.state
    Box(Modifier.fillMaxSize().background(Dark)) {
        when (val screen = state.screen) {
            Screen.Setup -> SetupScreen(state, vm::connect)
            Screen.Channels -> ChannelsScreen(state, vm::selectCategory, vm::play, vm::toggleFavorite, vm::disconnect)
            is Screen.Player -> PlayerScreen(screen, vm::backToChannels)
        }
        if (state.busy) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Gold)
    }
}

@Composable private fun SetupScreen(state: AppState, onConnect: (String, String) -> Unit) {
    var url by remember { mutableStateOf("") }
    var mac by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(horizontal = 72.dp), verticalArrangement = Arrangement.Center) {
        androidx.compose.foundation.Image(
            painter = painterResource(R.drawable.app_logo),
            contentDescription = "GOLDSTB PRO",
            contentScale = ContentScale.Fit,
            modifier = Modifier.height(180.dp).fillMaxWidth()
        )
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(url, { url = it }, label = { Text("Portal URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(mac, { mac = it }, label = { Text("Authorized MAC address") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 12.dp)) }
        Button(onClick = { onConnect(url, mac) }, enabled = url.isNotBlank() && mac.isNotBlank() && !state.busy, modifier = Modifier.padding(top = 24.dp)) { Text("CONNECT") }
    }
}

@Composable private fun ChannelsScreen(state: AppState, select: (String?) -> Unit, play: (Channel) -> Unit, favorite: (String) -> Unit, disconnect: () -> Unit) {
    val shown = state.channels.filter { state.selectedCategory == null || it.categoryId == state.selectedCategory }
    Column(Modifier.fillMaxSize().padding(28.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("GOLDSTB PRO", style = MaterialTheme.typography.headlineMedium, color = Gold)
            Spacer(Modifier.weight(1f)); TextButton(onClick = disconnect) { Text("CHANGE PORTAL") }
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 18.dp)) {
            item { FilterChip(selected = state.selectedCategory == null, onClick = { select(null) }, label = { Text("All") }) }
            items(state.categories) { c -> FilterChip(selected = state.selectedCategory == c.id, onClick = { select(c.id) }, label = { Text(c.title) }) }
        }
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (shown.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No channels in this category") }
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown, key = { it.id }) { channel ->
                Surface(Modifier.fillMaxWidth().clickable { play(channel) }, tonalElevation = 2.dp) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(channel.name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        IconButton(onClick = { favorite(channel.id) }) {
                            Icon(if (channel.id in state.favorites) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Favorite", tint = Gold)
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun PlayerScreen(screen: Screen.Player, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(screen.url) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(screen.url)); prepare(); playWhenReady = true } }
    DisposableEffect(player) { onDispose { player.release() } }
    BackHandler(onBack = onBack)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true; layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT) } }, modifier = Modifier.fillMaxSize())
        Text(screen.channel.name, Modifier.align(Alignment.TopStart).padding(18.dp).background(Color(0x99000000)).padding(10.dp), color = Color.White)
    }
}
