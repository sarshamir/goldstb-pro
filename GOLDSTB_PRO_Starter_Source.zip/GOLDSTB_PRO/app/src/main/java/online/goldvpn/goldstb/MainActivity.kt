package online.goldvpn.goldstb

import android.os.Bundle
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

private val Gold = Color(0xFFD49A00)
private val BrightGold = Color(0xFFFFC928)
private val Dark = Color(0xFF090B0E)
private val Panel = Color(0xFF15191F)
private const val FAVORITES = "__favorites"
private const val RECENT = "__recent"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoldStbTheme { GoldStbApp() } }
    }
}

@Composable private fun GoldStbTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Dark, surface = Panel), content = content)
}

@Composable private fun GoldStbApp(vm: MainViewModel = viewModel()) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val preferences = remember { context.getSharedPreferences("goldstb_preferences", android.content.Context.MODE_PRIVATE) }
    var legalAccepted by remember { mutableStateOf(preferences.getBoolean("legal_accepted_v1", false)) }
    var showLegal by remember { mutableStateOf(!legalAccepted) }
    val state by vm.state
    Box(Modifier.fillMaxSize().background(Dark)) {
        when {
            showLegal -> LegalScreen(!legalAccepted, {
                preferences.edit().putBoolean("legal_accepted_v1", true).apply()
                legalAccepted = true
                showLegal = false
            }, { if (legalAccepted) showLegal = false })
            state.screen == Screen.Setup -> SetupScreen(state, vm::connect) { showLegal = true }
            state.screen == Screen.Library -> LibraryScreen(state, vm::selectSection, vm::openCategory, vm::editPortal) { showLegal = true }
            state.screen == Screen.Content -> ContentScreen(state, vm::search, vm::play, vm::toggleFavorite, vm::backToLibrary)
            state.screen is Screen.ConnectionError -> ConnectionErrorScreen(state, state.screen as Screen.ConnectionError, vm::retry, vm::editPortal)
            state.screen is Screen.Player -> PlayerScreen(state.screen as Screen.Player, vm::backToChannels)
        }
        if (state.busy) LoadingScreen(state.loadingProgress, state.connectionLabel ?: "Loading…")
    }
}

@Composable private fun LoadingScreen(progress: Float, label: String) {
    Box(Modifier.fillMaxSize().background(Color(0xFF052E4C)), contentAlignment = Alignment.Center) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("GOLDSTB", color = BrightGold, style = MaterialTheme.typography.displaySmall)
            Text("PREMIUM MEDIA PLAYER", color = Color(0xFFB8C8D6), style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(64.dp))
            LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(12.dp),
                color = BrightGold,
                trackColor = Color(0xFF315A78)
            )
            Text(label, Modifier.padding(top = 16.dp), color = Color.White)
        }
    }
}

@Composable private fun SetupScreen(
    state: AppState,
    onConnect: (String, String) -> Unit,
    onLegal: () -> Unit
) {
    val configuration = LocalConfiguration.current
    val horizontalPadding = if (configuration.screenWidthDp < 600) 20.dp else 64.dp
    var url by remember(state.config) { mutableStateOf(formatPortalInput(state.config?.baseUrl.orEmpty())) }
    var macField by remember(state.config) {
        val initial = formatMacInput(state.config?.mac.orEmpty())
        mutableStateOf(TextFieldValue(initial, selection = TextRange(initial.length)))
    }
    val mac = macField.text
    val canConnect = url.trim().isNotEmpty() && isValidMac(mac)
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = horizontalPadding, vertical = 20.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painterResource(R.drawable.app_logo),
            "GOLDSTB PRO",
            Modifier.heightIn(max = 130.dp).fillMaxWidth(),
            contentScale = ContentScale.Fit
        )
        Text("PORTAL SETTINGS", style = MaterialTheme.typography.headlineSmall, color = Gold)
        Text("One portal is saved automatically and opens whenever GOLDSTB PRO starts.", color = Color.Gray, modifier = Modifier.padding(top = 6.dp, bottom = 20.dp))
        OutlinedTextField(
            value = url,
            onValueChange = { url = it.trimStart() },
            label = { Text("Portal URL *") },
            placeholder = { Text("portal.example.com/c/") },
            supportingText = { Text("Accepted with or without http:// or https://") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(18.dp))
        Text("Authorized MAC Address *", style = MaterialTheme.typography.titleMedium, color = Color.White)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = macField,
            onValueChange = { incoming ->
                val formatted = formatMacInput(incoming.text)
                macField = TextFieldValue(formatted, selection = TextRange(formatted.length))
            },
            placeholder = { Text("XX:XX:XX:XX:XX:XX") },
            supportingText = { Text("MAC address format: XX:XX:XX:XX:XX:XX") },
            isError = mac.isNotEmpty() && !isValidMac(mac),
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.Characters,
                keyboardType = KeyboardType.Ascii
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Text("Register this MAC address with your authorized provider.", color = Color.Gray)
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp)) }
        Row(Modifier.padding(top = 22.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = { onConnect(formatPortalInput(url), mac) },
                enabled = canConnect && !state.busy,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Gold,
                    contentColor = Color.Black,
                    disabledContainerColor = Color(0xFF4B4B4B),
                    disabledContentColor = Color(0xFFAAAAAA)
                )
            ) { Text("SAVE & CONNECT") }
            TextButton(onClick = onLegal) { Text("LEGAL & PRIVACY") }
        }
        Text("Player only — no channels, portals, playlists, or subscriptions are provided.", color = Color.Gray, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 18.dp))
    }
}

private fun formatMacInput(value: String): String {
    val hex = value.uppercase().filter { it in '0'..'9' || it in 'A'..'F' }.take(12)
    return hex.chunked(2).joinToString(":")
}

private fun formatPortalInput(value: String): String = value.trim()

private fun isValidMac(value: String): Boolean =
    Regex("^([0-9A-F]{2}:){5}[0-9A-F]{2}$").matches(value)

@Composable private fun LibraryScreen(
    state: AppState,
    selectSection: (MediaKind) -> Unit,
    openCategory: (Category?) -> Unit,
    settings: () -> Unit,
    legal: () -> Unit
) {
    val categories = if (state.selectedKind == MediaKind.LIVE) state.liveCategories else state.vodCategories
    BackHandler(onBack = settings)
    Column(Modifier.fillMaxSize().background(Dark)) {
        BrandHeader(settings, legal)
        Text(if (state.selectedKind == MediaKind.LIVE) "LIVE TV CATEGORIES" else "VOD CATEGORIES", color = BrightGold, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            item { LibraryCategory("★  FAVORITES") { openCategory(Category(FAVORITES, "Favorites", state.selectedKind)) } }
            item { LibraryCategory("ALL") { openCategory(null) } }
            items(categories, key = { "${it.kind}-${it.id}" }) { category -> LibraryCategory(category.title.uppercase()) { openCategory(category) } }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FeatureTile("TV", Icons.Filled.LiveTv, Color(0xFF1976D2), state.selectedKind == MediaKind.LIVE, Modifier.weight(1f)) { selectSection(MediaKind.LIVE) }
            FeatureTile("VOD", Icons.Filled.Movie, Color(0xFFE65100), state.selectedKind == MediaKind.VOD, Modifier.weight(1f)) { selectSection(MediaKind.VOD) }
            FeatureTile("INFO", Icons.Filled.Info, Color(0xFF7B1FA2), false, Modifier.weight(1f), legal)
        }
    }
}

@Composable private fun BrandHeader(settings: () -> Unit, legal: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF0C1015)).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(settings) { Icon(Icons.Filled.Settings, "Portal settings", tint = Color(0xFF64B5F6)) }
        IconButton(legal) { Icon(Icons.Filled.Info, "Information", tint = Color(0xFFAB47BC)) }
        Spacer(Modifier.weight(1f))
        Text("GOLDSTB", color = BrightGold, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.weight(1f))
        Icon(Icons.Filled.Star, "Favorites", tint = BrightGold, modifier = Modifier.padding(12.dp))
    }
}

@Composable private fun LibraryCategory(label: String, click: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clickable(onClick = click).focusable(), color = Color(0xFF292D32), shape = MaterialTheme.shapes.medium, border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF697078))) {
        Row(Modifier.padding(horizontal = 18.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), color = Color.White, maxLines = 1)
            Icon(Icons.Outlined.FavoriteBorder, "Favorite category", tint = BrightGold)
        }
    }
}

@Composable private fun FeatureTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, selected: Boolean, modifier: Modifier, click: () -> Unit) {
    Surface(modifier.height(92.dp).clickable(onClick = click).focusable(), color = if (selected) color else color.copy(alpha = .62f), shape = MaterialTheme.shapes.large, border = if (selected) androidx.compose.foundation.BorderStroke(2.dp, BrightGold) else null) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, label, tint = Color.White, modifier = Modifier.size(34.dp))
            Text(label, color = Color.White, style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable private fun ContentScreen(state: AppState, search: (String) -> Unit, play: (Channel) -> Unit, favorite: (String) -> Unit, back: () -> Unit) {
    BackHandler(onBack = back)
    val base = if (state.selectedKind == MediaKind.LIVE) state.liveChannels else state.vodItems
    val shown = base.filter { item ->
        val categoryMatch = when (state.selectedCategory) {
            null -> true
            FAVORITES -> item.id in state.favorites
            else -> state.selectedKind == MediaKind.VOD || item.categoryId == state.selectedCategory
        }
        categoryMatch && item.name.contains(state.query, true)
    }
    Column(Modifier.fillMaxSize().background(Dark)) {
        Row(Modifier.fillMaxWidth().background(Color(0xFF0C1015)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(back) { Icon(Icons.Filled.ArrowBack, "Categories", tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text(if (state.selectedKind == MediaKind.LIVE) "LIVE TV" else "VOD", color = BrightGold, style = MaterialTheme.typography.titleLarge)
                Text(state.selectedCategoryTitle, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            }
        }
        OutlinedTextField(state.query, search, label = { Text("Search") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp))
        Text("${shown.size} items", color = Color.Gray, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(shown, key = { "${it.kind}-${it.id}" }) { item ->
                Surface(Modifier.fillMaxWidth().clickable { play(item) }.focusable(), color = Panel, shape = MaterialTheme.shapes.medium) {
                    Row(Modifier.padding(start = 15.dp, end = 5.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (item.kind == MediaKind.LIVE) Icons.Filled.LiveTv else Icons.Filled.Movie, null, tint = if (item.kind == MediaKind.LIVE) Color(0xFF42A5F5) else Color(0xFFFF7043))
                        Text(item.name, Modifier.weight(1f).padding(start = 12.dp), maxLines = 2)
                        IconButton({ favorite(item.id) }) { Icon(if (item.id in state.favorites) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Favorite", tint = BrightGold) }
                    }
                }
            }
        }
    }
}

@Composable private fun ConnectionErrorScreen(state: AppState, problem: Screen.ConnectionError, retry: () -> Unit, settings: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val title = when (problem.type) {
        ConnectionProblem.EXPIRED_OR_BLOCKED -> "Subscription inactive"
        ConnectionProblem.NOT_AUTHORIZED -> "MAC not authorized"
        ConnectionProblem.PORTAL_NOT_FOUND -> "Portal not found"
        ConnectionProblem.INVALID_RESPONSE -> "Portal response problem"
        ConnectionProblem.NETWORK -> "Connection problem"
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF082B49)).padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("GOLDSTB", color = BrightGold, style = MaterialTheme.typography.displaySmall)
            Spacer(Modifier.height(34.dp))
            Text(title, color = Color.White, style = MaterialTheme.typography.headlineMedium)
            Text(problem.message, color = Color(0xFFD6E2EC), modifier = Modifier.padding(top = 12.dp), maxLines = 4)
            state.config?.mac?.let { Text("MAC: $it", color = BrightGold, modifier = Modifier.padding(top = 12.dp)) }
            Row(Modifier.padding(top = 30.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(retry, colors = ButtonDefaults.buttonColors(containerColor = BrightGold, contentColor = Color.Black)) { Icon(Icons.Filled.Refresh, null); Text(" RETRY") }
                OutlinedButton(settings) { Text("PORTAL SETTINGS") }
            }
            state.config?.mac?.let { mac ->
                TextButton(onClick = {
                    val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("GOLDSTB MAC", mac))
                }) { Icon(Icons.Filled.ContentCopy, null); Text(" COPY MAC") }
            }
        }
    }
}

@Composable private fun LegalScreen(firstRun: Boolean, onAccept: () -> Unit, onBack: () -> Unit) {
    if (!firstRun) BackHandler(onBack = onBack)
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val compact = maxWidth < 600.dp || maxHeight < 560.dp
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(
                horizontal = if (compact) 16.dp else 64.dp,
                vertical = if (compact) 18.dp else 36.dp
            ),
            verticalArrangement = Arrangement.spacedBy(if (compact) 10.dp else 14.dp)
        ) {
            Text("GOLDSTB PRO — Legal Notice", style = if (compact) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.headlineMedium, color = Gold)
            Text("Media player only", style = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleLarge)
            Text("GOLDSTB PRO is an independent media-player client. It does not include, sell, supply, host, retransmit, or recommend channels, streams, playlists, portals, or subscriptions.")
            Text("Authorized use", style = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleLarge)
            Text("You must provide your own portal details and connect only to services and content that you are legally authorized to access. The app must not be used for pirated or unlawful content.")
            Text("Privacy", style = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleLarge)
            Text("Portal details, favourites, recent channels, profiles, and acceptance of this notice are stored locally. Connection details are sent only to the portal you choose.")
            Text("By continuing, you confirm that you understand this notice and will use the app only with authorized content.", color = Gold)
            if (compact) {
                Button(onAccept, Modifier.fillMaxWidth()) { Text(if (firstRun) "ACCEPT AND CONTINUE" else "DONE") }
                if (!firstRun) OutlinedButton(onBack, Modifier.fillMaxWidth()) { Text("BACK") }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onAccept) { Text(if (firstRun) "ACCEPT AND CONTINUE" else "DONE") }
                    if (!firstRun) OutlinedButton(onBack) { Text("BACK") }
                }
            }
        }
    }
}

@Composable private fun PlayerScreen(screen: Screen.Player, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var playbackError by remember(screen.source.url) { mutableStateOf<String?>(null) }
    val player = remember(screen.source.url) {
        val dataSourceFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent(screen.source.headers["User-Agent"] ?: "GOLDSTB PRO")
            .setDefaultRequestProperties(screen.source.headers)
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(DefaultMediaSourceFactory(context).setDataSourceFactory(dataSourceFactory))
            .build()
    }
    DisposableEffect(player, screen.source.url) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                playbackError = when (error.errorCode) {
                    PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> "The portal rejected the stream request."
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> "The stream server could not be reached."
                    PlaybackException.ERROR_CODE_DECODING_FAILED,
                    PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED -> "This device cannot decode the channel format."
                    else -> error.message ?: "This channel could not be played."
                }
            }
        }
        player.addListener(listener)
        runCatching {
            player.setMediaItem(MediaItem.fromUri(screen.source.url))
            player.prepare()
            player.playWhenReady = true
        }.onFailure { playbackError = it.message ?: "This channel could not be opened." }
        onDispose {
            player.removeListener(listener)
            player.stop()
            player.release()
        }
    }
    BackHandler(onBack = onBack)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView({ PlayerView(it).apply { this.player = player; useController = true; layoutParams = ViewGroup.LayoutParams(-1, -1) } }, modifier = Modifier.fillMaxSize())
        Text(screen.channel.name, Modifier.align(Alignment.TopStart).padding(18.dp).background(Color(0xAA000000)).padding(10.dp), color = Color.White)
        playbackError?.let { message ->
            Column(
                Modifier.align(Alignment.Center).background(Color(0xDD111419)).padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Playback unavailable", color = Gold, style = MaterialTheme.typography.titleLarge)
                Text(message, color = Color.White, modifier = Modifier.padding(vertical = 12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = {
                        playbackError = null
                        player.prepare()
                        player.play()
                    }) { Text("TRY AGAIN") }
                    OutlinedButton(onClick = onBack) { Text("BACK TO CHANNELS") }
                }
            }
        }
    }
}
