package online.goldvpn.goldstb

import android.os.Bundle
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

private val Gold = Color(0xFFF5B700)
private val Dark = Color(0xFF090B0E)
private val Panel = Color(0xFF15191F)
private const val FAVORITES = "__favorites"
private const val RECENT = "__recent"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoldStbTheme { GoldStbApp() } }
    }
}

@Composable private fun GoldStbTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Dark, surface = Panel), content = content)
}

@Composable private fun GoldStbApp(vm: MainViewModel = viewModel()) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val preferences = remember { context.getSharedPreferences("goldstb_preferences", android.content.Context.MODE_PRIVATE) }
    var legalAccepted by remember { mutableStateOf(preferences.getBoolean("legal_accepted_v1", false)) }
    var showLegal by remember { mutableStateOf(!legalAccepted) }
    val state by vm.state
    Box(Modifier.fillMaxSize().background(Dark)) {
        when {
            showLegal -> LegalScreen(!legalAccepted, {
                preferences.edit().putBoolean("legal_accepted_v1", true).apply()
                legalAccepted = true
                showLegal = false
            }, { if (legalAccepted) showLegal = false })
            state.screen == Screen.Setup -> SetupScreen(state, vm::connect) { showLegal = true }
            state.screen == Screen.Channels -> ChannelsScreen(state, vm::selectCategory, vm::search, vm::play, vm::toggleFavorite, vm::disconnect)
            state.screen is Screen.Player -> PlayerScreen(state.screen as Screen.Player, vm::backToChannels)
        }
        if (state.busy) Box(Modifier.fillMaxSize().background(Color(0x77000000)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = Gold)
                state.connectionLabel?.let { Text(it, Modifier.padding(top = 12.dp), color = Color.White) }
            }
        }
    }
}

@Composable private fun SetupScreen(
    state: AppState,
    onConnect: (String, String) -> Unit,
    onLegal: () -> Unit
) {
    val configuration = LocalConfiguration.current
    val horizontalPadding = if (configuration.screenWidthDp < 600) 20.dp else 64.dp
    var url by remember(state.config) { mutableStateOf(formatPortalInput(state.config?.baseUrl.orEmpty())) }
    var macField by remember(state.config) {
        val initial = formatMacInput(state.config?.mac.orEmpty())
        mutableStateOf(TextFieldValue(initial, selection = TextRange(initial.length)))
    }
    val mac = macField.text
    val canConnect = url.trim().isNotEmpty() && isValidMac(mac)
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = horizontalPadding, vertical = 20.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painterResource(R.drawable.app_logo),
            "GOLDSTB PRO",
            Modifier.heightIn(max = 130.dp).fillMaxWidth(),
            contentScale = ContentScale.Fit
        )
        Text("PORTAL SETTINGS", style = MaterialTheme.typography.headlineSmall, color = Gold)
        Text("One portal is saved automatically and opens whenever GOLDSTB PRO starts.", color = Color.Gray, modifier = Modifier.padding(top = 6.dp, bottom = 20.dp))
        OutlinedTextField(
            value = url,
            onValueChange = { url = it.trimStart() },
            label = { Text("Portal URL *") },
            placeholder = { Text("portal.example.com/c/") },
            supportingText = { Text("Accepted with or without http:// or https://") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(18.dp))
        Text("Authorized MAC Address *", style = MaterialTheme.typography.titleMedium, color = Color.White)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = macField,
            onValueChange = { incoming ->
                val formatted = formatMacInput(incoming.text)
                macField = TextFieldValue(formatted, selection = TextRange(formatted.length))
            },
            placeholder = { Text("XX:XX:XX:XX:XX:XX") },
            supportingText = { Text("MAC address format: XX:XX:XX:XX:XX:XX") },
            isError = mac.isNotEmpty() && !isValidMac(mac),
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.Characters,
                keyboardType = KeyboardType.Ascii
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Text("Register this MAC address with your authorized provider.", color = Color.Gray)
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp)) }
        Row(Modifier.padding(top = 22.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = { onConnect(formatPortalInput(url), mac) },
                enabled = canConnect && !state.busy,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Gold,
                    contentColor = Color.Black,
                    disabledContainerColor = Color(0xFF4B4B4B),
                    disabledContentColor = Color(0xFFAAAAAA)
                )
            ) { Text("SAVE & CONNECT") }
            TextButton(onClick = onLegal) { Text("LEGAL & PRIVACY") }
        }
        Text("Player only — no channels, portals, playlists, or subscriptions are provided.", color = Color.Gray, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 18.dp))
    }
}

private fun formatMacInput(value: String): String {
    val hex = value.uppercase().filter { it in '0'..'9' || it in 'A'..'F' }.take(12)
    return hex.chunked(2).joinToString(":")
}

private fun formatPortalInput(value: String): String = value.trim()

private fun isValidMac(value: String): Boolean =
    Regex("^([0-9A-F]{2}:){5}[0-9A-F]{2}$").matches(value)

@Composable private fun ChannelsScreen(
    state: AppState,
    select: (String?) -> Unit,
    search: (String) -> Unit,
    play: (Channel) -> Unit,
    favorite: (String) -> Unit,
    disconnect: () -> Unit
) {
    val shown = state.channels.filter { channel ->
        val categoryMatch = when (state.selectedCategory) {
            null -> true
            FAVORITES -> channel.id in state.favorites
            RECENT -> channel.id in state.recentChannelIds
            else -> channel.categoryId == state.selectedCategory
        }
        categoryMatch && channel.name.contains(state.query, ignoreCase = true)
    }.let { list -> if (state.selectedCategory == RECENT) list.sortedBy { state.recentChannelIds.indexOf(it.id) } else list }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val phone = maxWidth < 840.dp || maxHeight < 560.dp
        Column(Modifier.fillMaxSize()) {
            if (phone) {
                Column(Modifier.fillMaxWidth().background(Color(0xFF101318)).padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("GOLDSTB PRO", color = Gold, style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.weight(1f))
                        TextButton(disconnect) { Text("PORTAL") }
                    }
                    OutlinedTextField(
                        state.query,
                        search,
                        label = { Text("Search Live TV or VOD") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                LazyRow(
                    Modifier.fillMaxWidth().background(Color(0xFF111419)).padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    item { CategoryChip("All", state.selectedCategory == null) { select(null) } }
                    item { CategoryChip("★ Favorites", state.selectedCategory == FAVORITES) { select(FAVORITES) } }
                    item { CategoryChip("↻ Recent", state.selectedCategory == RECENT) { select(RECENT) } }
                    items(state.categories) { c -> CategoryChip(c.title, state.selectedCategory == c.id) { select(c.id) } }
                }
                Text(
                    if (shown.isEmpty()) "No matching channels" else "${shown.size} items",
                    color = Color.Gray,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
                ChannelList(shown, state.favorites, play, favorite, Modifier.fillMaxWidth().weight(1f), compact = true)
            } else {
                Row(Modifier.fillMaxWidth().background(Color(0xFF101318)).padding(horizontal = 24.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("GOLDSTB PRO", color = Gold, style = MaterialTheme.typography.headlineSmall)
                    Text("  •  Connected portal", color = Color.LightGray)
                    Spacer(Modifier.weight(1f))
                    OutlinedTextField(state.query, search, label = { Text("Search Live TV or VOD") }, singleLine = true, modifier = Modifier.width(280.dp))
                    TextButton(disconnect, Modifier.padding(start = 12.dp)) { Text("PORTALS") }
                }
                Row(Modifier.fillMaxSize()) {
                    LazyColumn(Modifier.width(220.dp).fillMaxHeight().background(Color(0xFF111419)).padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        item { CategoryRow("All", state.selectedCategory == null) { select(null) } }
                        item { CategoryRow("★ Favorites", state.selectedCategory == FAVORITES) { select(FAVORITES) } }
                        item { CategoryRow("↻ Recent", state.selectedCategory == RECENT) { select(RECENT) } }
                        items(state.categories) { c -> CategoryRow(c.title, state.selectedCategory == c.id) { select(c.id) } }
                    }
                    ChannelList(shown, state.favorites, play, favorite, Modifier.weight(.55f).fillMaxHeight())
                    Column(Modifier.weight(.30f).fillMaxHeight().background(Color(0xFF111419)).padding(24.dp)) {
                        Text("LIVE TV / VOD", color = Gold, style = MaterialTheme.typography.labelLarge)
                        Spacer(Modifier.height(24.dp))
                        Text(shown.firstOrNull()?.name ?: "Select an item", style = MaterialTheme.typography.headlineSmall)
                        Spacer(Modifier.height(12.dp))
                        Text(if (shown.isEmpty()) "No matching items" else "${shown.size} items", color = Color.Gray)
                        Spacer(Modifier.weight(1f))
                        Text("OK  Play\n★  Add favorite\nBACK  Return", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable private fun ChannelList(
    channels: List<Channel>,
    favorites: Set<String>,
    play: (Channel) -> Unit,
    favorite: (String) -> Unit,
    modifier: Modifier,
    compact: Boolean = false
) {
    LazyColumn(modifier.padding(horizontal = if (compact) 8.dp else 10.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        items(channels, key = { it.id }) { channel ->
            Surface(Modifier.fillMaxWidth().clickable { play(channel) }.focusable(), color = Panel) {
                Row(Modifier.padding(start = if (compact) 12.dp else 16.dp, end = 4.dp, top = if (compact) 7.dp else 9.dp, bottom = if (compact) 7.dp else 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(channel.name, Modifier.weight(1f), style = if (compact) MaterialTheme.typography.bodyLarge else MaterialTheme.typography.titleMedium, maxLines = 2)
                    IconButton({ favorite(channel.id) }) {
                        Icon(if (channel.id in favorites) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Favorite", tint = Gold)
                    }
                }
            }
        }
    }
}

@Composable private fun CategoryChip(label: String, selected: Boolean, click: () -> Unit) {
    Surface(
        Modifier.clickable(onClick = click).focusable(),
        color = if (selected) Gold else Panel,
        shape = MaterialTheme.shapes.large
    ) {
        Text(label, Modifier.padding(horizontal = 14.dp, vertical = 9.dp), color = if (selected) Color.Black else Color.White, maxLines = 1)
    }
}

@Composable private fun CategoryRow(label: String, selected: Boolean, click: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clickable(onClick = click).focusable(), color = if (selected) Gold else Color.Transparent) {
        Text(label, Modifier.padding(horizontal = 14.dp, vertical = 12.dp), color = if (selected) Color.Black else Color.White)
    }
}

@Composable private fun LegalScreen(firstRun: Boolean, onAccept: () -> Unit, onBack: () -> Unit) {
    if (!firstRun) BackHandler(onBack = onBack)
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val compact = maxWidth < 600.dp || maxHeight < 560.dp
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(
                horizontal = if (compact) 16.dp else 64.dp,
                vertical = if (compact) 18.dp else 36.dp
            ),
            verticalArrangement = Arrangement.spacedBy(if (compact) 10.dp else 14.dp)
        ) {
            Text("GOLDSTB PRO — Legal Notice", style = if (compact) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.headlineMedium, color = Gold)
            Text("Media player only", style = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleLarge)
            Text("GOLDSTB PRO is an independent media-player client. It does not include, sell, supply, host, retransmit, or recommend channels, streams, playlists, portals, or subscriptions.")
            Text("Authorized use", style = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleLarge)
            Text("You must provide your own portal details and connect only to services and content that you are legally authorized to access. The app must not be used for pirated or unlawful content.")
            Text("Privacy", style = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleLarge)
            Text("Portal details, favourites, recent channels, profiles, and acceptance of this notice are stored locally. Connection details are sent only to the portal you choose.")
            Text("By continuing, you confirm that you understand this notice and will use the app only with authorized content.", color = Gold)
            if (compact) {
                Button(onAccept, Modifier.fillMaxWidth()) { Text(if (firstRun) "ACCEPT AND CONTINUE" else "DONE") }
                if (!firstRun) OutlinedButton(onBack, Modifier.fillMaxWidth()) { Text("BACK") }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onAccept) { Text(if (firstRun) "ACCEPT AND CONTINUE" else "DONE") }
                    if (!firstRun) OutlinedButton(onBack) { Text("BACK") }
                }
            }
        }
    }
}

@Composable private fun PlayerScreen(screen: Screen.Player, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var playbackError by remember(screen.source.url) { mutableStateOf<String?>(null) }
    val player = remember(screen.source.url) {
        val dataSourceFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent(screen.source.headers["User-Agent"] ?: "GOLDSTB PRO")
            .setDefaultRequestProperties(screen.source.headers)
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(DefaultMediaSourceFactory(context).setDataSourceFactory(dataSourceFactory))
            .build()
    }
    DisposableEffect(player, screen.source.url) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                playbackError = when (error.errorCode) {
                    PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> "The portal rejected the stream request."
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> "The stream server could not be reached."
                    PlaybackException.ERROR_CODE_DECODING_FAILED,
                    PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED -> "This device cannot decode the channel format."
                    else -> error.message ?: "This channel could not be played."
                }
            }
        }
        player.addListener(listener)
        runCatching {
            player.setMediaItem(MediaItem.fromUri(screen.source.url))
            player.prepare()
            player.playWhenReady = true
        }.onFailure { playbackError = it.message ?: "This channel could not be opened." }
        onDispose {
            player.removeListener(listener)
            player.stop()
            player.release()
        }
    }
    BackHandler(onBack = onBack)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView({ PlayerView(it).apply { this.player = player; useController = true; layoutParams = ViewGroup.LayoutParams(-1, -1) } }, modifier = Modifier.fillMaxSize())
        Text(screen.channel.name, Modifier.align(Alignment.TopStart).padding(18.dp).background(Color(0xAA000000)).padding(10.dp), color = Color.White)
        playbackError?.let { message ->
            Column(
                Modifier.align(Alignment.Center).background(Color(0xDD111419)).padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Playback unavailable", color = Gold, style = MaterialTheme.typography.titleLarge)
                Text(message, color = Color.White, modifier = Modifier.padding(vertical = 12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = {
                        playbackError = null
                        player.prepare()
                        player.play()
                    }) { Text("TRY AGAIN") }
                    OutlinedButton(onClick = onBack) { Text("BACK TO CHANNELS") }
                }
            }
        }
    }
}
