package online.goldvpn.goldstb

import android.os.Bundle
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private val Gold = Color(0xFFF5B700)
private val Dark = Color(0xFF090B0E)
private val Panel = Color(0xFF15191F)
private const val FAVORITES = "__favorites"
private const val RECENT = "__recent"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoldStbTheme { GoldStbApp() } }
    }
}

@Composable private fun GoldStbTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Dark, surface = Panel), content = content)
}

@Composable private fun GoldStbApp(vm: MainViewModel = viewModel()) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val preferences = remember { context.getSharedPreferences("goldstb_preferences", android.content.Context.MODE_PRIVATE) }
    var legalAccepted by remember { mutableStateOf(preferences.getBoolean("legal_accepted_v1", false)) }
    var showLegal by remember { mutableStateOf(!legalAccepted) }
    val state by vm.state
    Box(Modifier.fillMaxSize().background(Dark)) {
        when {
            showLegal -> LegalScreen(!legalAccepted, {
                preferences.edit().putBoolean("legal_accepted_v1", true).apply()
                legalAccepted = true
                showLegal = false
            }, { if (legalAccepted) showLegal = false })
            state.screen == Screen.Setup -> SetupScreen(state, vm::connect, vm::deleteProfile) { showLegal = true }
            state.screen == Screen.Channels -> ChannelsScreen(state, vm::selectCategory, vm::search, vm::play, vm::toggleFavorite, vm::disconnect)
            state.screen is Screen.Player -> PlayerScreen(state.screen as Screen.Player, vm::backToChannels)
        }
        if (state.busy) Box(Modifier.fillMaxSize().background(Color(0x77000000)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = Gold)
                state.connectionLabel?.let { Text(it, Modifier.padding(top = 12.dp), color = Color.White) }
            }
        }
    }
}

@Composable private fun SetupScreen(
    state: AppState,
    onConnect: (String, String, String, Boolean) -> Unit,
    onDelete: (PortalConfig) -> Unit,
    onLegal: () -> Unit
) {
    var name by remember { mutableStateOf("My portal") }
    var url by remember { mutableStateOf("") }
    var mac by remember { mutableStateOf("") }
    var rememberProfile by remember { mutableStateOf(true) }
    Row(Modifier.fillMaxSize().padding(42.dp), horizontalArrangement = Arrangement.spacedBy(36.dp)) {
        Column(Modifier.weight(.42f).fillMaxHeight()) {
            Image(painterResource(R.drawable.app_logo), "GOLDSTB PRO", Modifier.height(140.dp).fillMaxWidth(), contentScale = ContentScale.Fit)
            Text("PORTAL PROFILES", style = MaterialTheme.typography.titleLarge, color = Gold, modifier = Modifier.padding(vertical = 18.dp))
            if (state.savedProfiles.isEmpty()) Text("No saved portals", color = Color.Gray)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(state.savedProfiles) { profile ->
                    Surface(Modifier.fillMaxWidth().clickable { name = profile.name; url = profile.baseUrl; mac = profile.mac }, color = Panel) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(profile.name)
                                Text(profile.baseUrl, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton({ onDelete(profile) }) { Icon(Icons.Default.Delete, "Delete profile", tint = Color.Gray) }
                        }
                    }
                }
            }
        }
        VerticalDivider(color = Color(0xFF30343A))
        Column(Modifier.weight(.58f).fillMaxHeight(), verticalArrangement = Arrangement.Center) {
            Text("ADD OR CONNECT", style = MaterialTheme.typography.headlineSmall, color = Gold)
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(name, { name = it }, label = { Text("Profile name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(url, { url = it }, label = { Text("Portal URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(mac, { mac = it }, label = { Text("Authorized MAC address") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(rememberProfile, { rememberProfile = it })
                Text("Remember this portal on this device")
            }
            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 8.dp)) }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button({ onConnect(name, url, mac, rememberProfile) }, enabled = url.isNotBlank() && mac.isNotBlank() && !state.busy) { Text("CONNECT") }
                TextButton(onClick = onLegal) { Text("LEGAL & PRIVACY") }
            }
            Text("Player only — no channels, portals, playlists, or subscriptions are provided.", color = Color.Gray, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 18.dp))
        }
    }
}

@Composable private fun ChannelsScreen(
    state: AppState,
    select: (String?) -> Unit,
    search: (String) -> Unit,
    play: (Channel) -> Unit,
    favorite: (String) -> Unit,
    disconnect: () -> Unit
) {
    val shown = state.channels.filter { channel ->
        val categoryMatch = when (state.selectedCategory) {
            null -> true
            FAVORITES -> channel.id in state.favorites
            RECENT -> channel.id in state.recentChannelIds
            else -> channel.categoryId == state.selectedCategory
        }
        categoryMatch && channel.name.contains(state.query, ignoreCase = true)
    }.let { list -> if (state.selectedCategory == RECENT) list.sortedBy { state.recentChannelIds.indexOf(it.id) } else list }
    val selected = shown.firstOrNull()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Color(0xFF101318)).padding(horizontal = 24.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("GOLDSTB PRO", color = Gold, style = MaterialTheme.typography.headlineSmall)
            Text("  •  ${state.config?.name.orEmpty()}", color = Color.LightGray)
            Spacer(Modifier.weight(1f))
            OutlinedTextField(state.query, search, label = { Text("Search channels") }, singleLine = true, modifier = Modifier.width(280.dp))
            TextButton(disconnect, Modifier.padding(start = 12.dp)) { Text("PORTALS") }
        }
        Row(Modifier.fillMaxSize()) {
            LazyColumn(Modifier.width(220.dp).fillMaxHeight().background(Color(0xFF111419)).padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                item { CategoryRow("All channels", state.selectedCategory == null) { select(null) } }
                item { CategoryRow("★ Favorites", state.selectedCategory == FAVORITES) { select(FAVORITES) } }
                item { CategoryRow("↻ Recent", state.selectedCategory == RECENT) { select(RECENT) } }
                items(state.categories) { c -> CategoryRow(c.title, state.selectedCategory == c.id) { select(c.id) } }
            }
            LazyColumn(Modifier.weight(.48f).fillMaxHeight().padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                items(shown, key = { it.id }) { channel ->
                    Surface(Modifier.fillMaxWidth().clickable { play(channel) }.focusable(), color = Panel) {
                        Row(Modifier.padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(channel.name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                            IconButton({ favorite(channel.id) }) {
                                Icon(if (channel.id in state.favorites) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Favorite", tint = Gold)
                            }
                        }
                    }
                }
            }
            Column(Modifier.weight(.32f).fillMaxHeight().background(Color(0xFF111419)).padding(24.dp)) {
                Text("NOW PLAYING", color = Gold, style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(24.dp))
                Text(selected?.name ?: "Select a channel", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(12.dp))
                Text(if (shown.isEmpty()) "No matching channels" else "${shown.size} channels", color = Color.Gray)
                Spacer(Modifier.weight(1f))
                Text("OK  Play channel\n★  Add favorite\nBACK  Return", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable private fun CategoryRow(label: String, selected: Boolean, click: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clickable(onClick = click).focusable(), color = if (selected) Gold else Color.Transparent) {
        Text(label, Modifier.padding(horizontal = 14.dp, vertical = 12.dp), color = if (selected) Color.Black else Color.White)
    }
}

@Composable private fun LegalScreen(firstRun: Boolean, onAccept: () -> Unit, onBack: () -> Unit) {
    if (!firstRun) BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 64.dp, vertical = 36.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("GOLDSTB PRO — Legal Notice", style = MaterialTheme.typography.headlineMedium, color = Gold)
        Text("Media player only", style = MaterialTheme.typography.titleLarge)
        Text("GOLDSTB PRO is an independent media-player client. It does not include, sell, supply, host, retransmit, or recommend channels, streams, playlists, portals, or subscriptions.")
        Text("Authorized use", style = MaterialTheme.typography.titleLarge)
        Text("You must provide your own portal details and connect only to services and content that you are legally authorized to access. The app must not be used for pirated or unlawful content.")
        Text("Privacy", style = MaterialTheme.typography.titleLarge)
        Text("Portal details, favourites, recent channels, profiles, and acceptance of this notice are stored locally. Connection details are sent only to the portal you choose.")
        Text("By continuing, you confirm that you understand this notice and will use the app only with authorized content.", color = Gold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onAccept) { Text(if (firstRun) "ACCEPT AND CONTINUE" else "DONE") }
            if (!firstRun) OutlinedButton(onBack) { Text("BACK") }
        }
    }
}

@Composable private fun PlayerScreen(screen: Screen.Player, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(screen.url) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(screen.url)); prepare(); playWhenReady = true } }
    DisposableEffect(player) { onDispose { player.release() } }
    BackHandler(onBack = onBack)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView({ PlayerView(it).apply { this.player = player; useController = true; layoutParams = ViewGroup.LayoutParams(-1, -1) } }, modifier = Modifier.fillMaxSize())
        Text(screen.channel.name, Modifier.align(Alignment.TopStart).padding(18.dp).background(Color(0xAA000000)).padding(10.dp), color = Color.White)
    }
}
