package online.goldvpn.goldstb

import android.os.Bundle
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Gold = Color(0xFFD6A72D)
private val BrightGold = Color(0xFFFFD65A)
private val Dark = Color(0xFF070A0F)
private val Panel = Color(0xFF151B24)
private val FocusSurface = Color(0xFF3C3012)
private val SoftTeal = Color(0xFF4DD6C5)
private const val FAVORITES = "__favorites"
private const val RECENT = "__recent"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoldStbTheme { GoldStbApp() } }
    }
}

@Composable private fun GoldStbTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Dark, surface = Panel), content = content)
}

@Composable private fun GoldStbApp(vm: MainViewModel = viewModel()) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val preferences = remember { context.getSharedPreferences("goldstb_preferences", android.content.Context.MODE_PRIVATE) }
    var legalAccepted by remember { mutableStateOf(preferences.getBoolean("legal_accepted_v1", false)) }
    var showLegal by remember { mutableStateOf(!legalAccepted) }
    var showInfo by remember { mutableStateOf(false) }
    val state by vm.state
    Box(Modifier.fillMaxSize().background(Dark)) {
        when {
            showLegal -> LegalScreen(!legalAccepted, {
                preferences.edit().putBoolean("legal_accepted_v1", true).apply()
                legalAccepted = true
                showLegal = false
            }, { if (legalAccepted) showLegal = false })
            showInfo -> InfoScreen(state) { showInfo = false }
            state.screen == Screen.Setup -> SetupScreen(state, vm::connect, vm::clearCache)
            state.screen == Screen.Library -> LibraryScreen(state, vm::selectSection, vm::openCategory, vm::editPortal) { showInfo = true }
            state.screen == Screen.Content -> ContentScreen(state, vm::search, vm::play, vm::toggleFavorite, vm::backToLibrary)
            state.screen is Screen.ConnectionError -> ConnectionErrorScreen(state, state.screen as Screen.ConnectionError, vm::retry, vm::editPortal)
            state.screen is Screen.Player -> PlayerScreen(state, state.screen as Screen.Player, vm::play, vm::backToChannels)
        }
        if (state.busy) LoadingScreen(state.loadingProgress, state.connectionLabel ?: "Loading…")
    }
}

@Composable private fun LoadingScreen(progress: Float, label: String) {
    Box(Modifier.fillMaxSize().background(Color(0xFF052E4C)), contentAlignment = Alignment.Center) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("GOLDSTB", color = BrightGold, style = MaterialTheme.typography.displaySmall)
            Text("PREMIUM MEDIA PLAYER", color = Color(0xFFB8C8D6), style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(64.dp))
            LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(12.dp),
                color = BrightGold,
                trackColor = Color(0xFF315A78)
            )
            Text(label, Modifier.padding(top = 16.dp), color = Color.White)
        }
    }
}

@Composable private fun SetupScreen(
    state: AppState,
    onConnect: (String, String) -> Unit,
    onClearCache: () -> Unit
) {
    val configuration = LocalConfiguration.current
    val horizontalPadding = if (configuration.screenWidthDp < 600) 20.dp else 64.dp
    var url by remember(state.config) { mutableStateOf(formatPortalInput(state.config?.baseUrl.orEmpty())) }
    var macField by remember(state.config) {
        val initial = formatMacInput(state.config?.mac.orEmpty())
        mutableStateOf(TextFieldValue(initial, selection = TextRange(initial.length)))
    }
    val mac = macField.text
    val canConnect = url.trim().isNotEmpty() && isValidMac(mac)
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = horizontalPadding, vertical = 20.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painterResource(R.drawable.app_logo),
            "GOLDSTB PRO",
            Modifier.heightIn(max = 130.dp).fillMaxWidth(),
            contentScale = ContentScale.Fit
        )
        Text("PORTAL SETTINGS", style = MaterialTheme.typography.headlineSmall, color = Gold)
        Text("One portal is saved automatically and opens whenever GOLDSTB PRO starts.", color = Color.Gray, modifier = Modifier.padding(top = 6.dp, bottom = 20.dp))
        OutlinedTextField(
            value = url,
            onValueChange = { url = it.trimStart() },
            label = { Text("Portal URL *") },
            placeholder = { Text("portal.example.com/c/") },
            supportingText = { Text("Accepted with or without http:// or https://") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(18.dp))
        Text("Authorized MAC Address *", style = MaterialTheme.typography.titleMedium, color = Color.White)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = macField,
            onValueChange = { incoming ->
                val formatted = formatMacInput(incoming.text)
                macField = TextFieldValue(formatted, selection = TextRange(formatted.length))
            },
            placeholder = { Text("XX:XX:XX:XX:XX:XX") },
            supportingText = { Text("MAC address format: XX:XX:XX:XX:XX:XX") },
            isError = mac.isNotEmpty() && !isValidMac(mac),
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.Characters,
                keyboardType = KeyboardType.Ascii
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Text("Register this MAC address with your authorized provider.", color = Color.Gray)
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp)) }
        Row(Modifier.padding(top = 22.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = { onConnect(formatPortalInput(url), mac) },
                enabled = canConnect && !state.busy,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Gold,
                    contentColor = Color.Black,
                    disabledContainerColor = Color(0xFF4B4B4B),
                    disabledContentColor = Color(0xFFAAAAAA)
                )
            ) { Text("SAVE & CONNECT") }
            OutlinedButton(onClick = onClearCache, enabled = !state.busy) { Text("CLEAR CACHE") }
        }
        state.settingsMessage?.let { Text(it, color = Color(0xFF81C784), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 14.dp)) }
    }
}

private fun formatMacInput(value: String): String {
    val hex = value.uppercase().filter { it in '0'..'9' || it in 'A'..'F' }.take(12)
    return hex.chunked(2).joinToString(":")
}

private fun formatPortalInput(value: String): String = value.trim()
    .removePrefix("https://")
    .removePrefix("http://")
    .trimEnd('/')

private fun isValidMac(value: String): Boolean =
    Regex("^([0-9A-F]{2}:){5}[0-9A-F]{2}$").matches(value)

@Composable private fun LibraryScreen(
    state: AppState,
    selectSection: (MediaKind) -> Unit,
    openCategory: (Category?) -> Unit,
    settings: () -> Unit,
    legal: () -> Unit
) {
    val categories = if (state.selectedKind == MediaKind.LIVE) state.liveCategories else state.vodCategories
    BackHandler(onBack = settings)
    Column(Modifier.fillMaxSize().background(Dark)) {
        BrandHeader(settings, legal)
        Text(if (state.selectedKind == MediaKind.LIVE) "LIVE TV CATEGORIES" else "VOD CATEGORIES", color = BrightGold, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            item { LibraryCategory("★  FAVORITES") { openCategory(Category(FAVORITES, "Favorites", state.selectedKind)) } }
            item { LibraryCategory("ALL") { openCategory(null) } }
            items(categories, key = { "${it.kind}-${it.id}" }) { category -> LibraryCategory(category.title.uppercase()) { openCategory(category) } }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FeatureTile("TV", Icons.Filled.LiveTv, Color(0xFF1976D2), state.selectedKind == MediaKind.LIVE, Modifier.weight(1f)) { selectSection(MediaKind.LIVE) }
            FeatureTile("VOD", Icons.Filled.Movie, Color(0xFFE65100), state.selectedKind == MediaKind.VOD, Modifier.weight(1f)) { selectSection(MediaKind.VOD) }
            FeatureTile("INFO", Icons.Filled.Info, Color(0xFF7B1FA2), false, Modifier.weight(1f), legal)
        }
    }
}

@Composable private fun BrandHeader(settings: () -> Unit, legal: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF0D121A)).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        TvIconButton(Icons.Filled.Settings, "Portal settings", BrightGold, settings)
        Spacer(Modifier.width(10.dp))
        TvIconButton(Icons.Filled.Info, "Information", SoftTeal, legal)
        Spacer(Modifier.weight(1f))
        Text("GOLDSTB", color = BrightGold, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.weight(1f))
        Icon(Icons.Filled.Star, "Favorites", tint = BrightGold, modifier = Modifier.padding(12.dp))
    }
}

@Composable private fun TvIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, tint: Color, click: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Surface(
        modifier = Modifier.size(54.dp).onFocusChanged { focused = it.isFocused }.clickable(onClick = click).focusable(),
        shape = CircleShape,
        color = if (focused) FocusSurface else Color(0xFF1A212C),
        border = androidx.compose.foundation.BorderStroke(if (focused) 4.dp else 1.dp, if (focused) BrightGold else Color(0xFF35404D))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, label, tint = if (focused) BrightGold else tint, modifier = Modifier.size(if (focused) 31.dp else 27.dp))
        }
    }
}

@Composable private fun LibraryCategory(label: String, click: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Surface(Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused }.clickable(onClick = click).focusable(), color = if (focused) FocusSurface else Panel, shape = MaterialTheme.shapes.medium, border = androidx.compose.foundation.BorderStroke(if (focused) 4.dp else 1.dp, if (focused) BrightGold else Color(0xFF394451))) {
        Row(Modifier.padding(horizontal = 18.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(16.dp).border(2.dp, if (focused) BrightGold else Color(0xFF697684), CircleShape), contentAlignment = Alignment.Center) {
                if (focused) Box(Modifier.size(8.dp).background(BrightGold, CircleShape))
            }
            Text(label, Modifier.weight(1f).padding(start = 12.dp), color = if (focused) BrightGold else Color.White, maxLines = 1)
            Icon(Icons.Outlined.FavoriteBorder, "Favorite category", tint = BrightGold)
        }
    }
}

@Composable private fun FeatureTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, selected: Boolean, modifier: Modifier, click: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Surface(modifier.height(96.dp).onFocusChanged { focused = it.isFocused }.clickable(onClick = click).focusable(), color = when { focused -> FocusSurface; selected -> color; else -> color.copy(alpha = .42f) }, shape = MaterialTheme.shapes.large, border = if (focused || selected) androidx.compose.foundation.BorderStroke(if (focused) 4.dp else 2.dp, BrightGold) else androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF35404D))) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, label, tint = if (focused) BrightGold else Color.White, modifier = Modifier.size(36.dp))
            Text(label, color = if (focused) BrightGold else Color.White, style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable private fun ContentScreen(state: AppState, search: (String) -> Unit, play: (Channel) -> Unit, favorite: (String) -> Unit, back: () -> Unit) {
    BackHandler(onBack = back)
    val context = androidx.compose.ui.platform.LocalContext.current
    val configuration = LocalConfiguration.current
    val isTelevision = (context.resources.configuration.uiMode and Configuration.UI_MODE_TYPE_MASK) == Configuration.UI_MODE_TYPE_TELEVISION ||
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK) || configuration.screenWidthDp >= 600
    val keyboard = LocalSoftwareKeyboardController.current
    var searchEditing by remember { mutableStateOf(false) }
    LaunchedEffect(searchEditing) { if (searchEditing) keyboard?.show() else keyboard?.hide() }
    val base = if (state.selectedKind == MediaKind.LIVE) state.liveChannels else state.vodItems
    val shown = base.filter { item ->
        val categoryMatch = when (state.selectedCategory) {
            null -> true
            FAVORITES -> item.id in state.favorites
            else -> state.selectedKind == MediaKind.VOD || item.categoryId == state.selectedCategory
        }
        categoryMatch && item.name.contains(state.query, true)
    }
    Column(Modifier.fillMaxSize().background(Dark)) {
        Row(Modifier.fillMaxWidth().background(Color(0xFF0C1015)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(back) { Icon(Icons.Filled.ArrowBack, "Categories", tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text(if (state.selectedKind == MediaKind.LIVE) "LIVE TV" else "VOD", color = BrightGold, style = MaterialTheme.typography.titleLarge)
                Text(state.selectedCategoryTitle, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            }
        }
        OutlinedTextField(
            value = state.query,
            onValueChange = search,
            label = { Text(if (!isTelevision || searchEditing) "Search" else "Search — press OK to type") },
            singleLine = true,
            readOnly = isTelevision && !searchEditing,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { searchEditing = false; keyboard?.hide() }),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .onFocusChanged {
                    if (!it.isFocused) searchEditing = false
                    if (it.isFocused && isTelevision && !searchEditing) keyboard?.hide()
                }
                .onPreviewKeyEvent { event ->
                    if (isTelevision && !searchEditing && event.type == KeyEventType.KeyDown &&
                        (event.key == Key.DirectionCenter || event.key == Key.Enter)
                    ) {
                        searchEditing = true
                        true
                    } else false
                }
        )
        Text("${shown.size} items", color = Color.Gray, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(shown, key = { "${it.kind}-${it.id}" }) { item ->
                var focused by remember(item.id) { mutableStateOf(false) }
                Surface(
                    Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused }.clickable { play(item) }.focusable(),
                    color = if (focused) FocusSurface else Panel,
                    shape = MaterialTheme.shapes.medium,
                    border = if (focused) androidx.compose.foundation.BorderStroke(4.dp, BrightGold) else androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF303A46))
                ) {
                    Row(Modifier.padding(start = 15.dp, end = 5.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(14.dp).border(2.dp, if (focused) BrightGold else Color(0xFF6B737C), CircleShape),
                            contentAlignment = Alignment.Center
                        ) { if (focused) Box(Modifier.size(6.dp).background(BrightGold, CircleShape)) }
                        Icon(if (item.kind == MediaKind.LIVE) Icons.Filled.LiveTv else Icons.Filled.Movie, null, tint = if (item.kind == MediaKind.LIVE) Color(0xFF42A5F5) else Color(0xFFFF7043))
                        Text(item.name, Modifier.weight(1f).padding(start = 12.dp), color = Color.White, maxLines = 2)
                        IconButton({ favorite(item.id) }) { Icon(if (item.id in state.favorites) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Favorite", tint = BrightGold) }
                    }
                }
            }
        }
    }
}

@Composable private fun ConnectionErrorScreen(state: AppState, problem: Screen.ConnectionError, retry: () -> Unit, settings: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val title = when (problem.type) {
        ConnectionProblem.NO_INTERNET -> "No internet connection"
        ConnectionProblem.EXPIRED_OR_BLOCKED -> "Subscription inactive"
        ConnectionProblem.NOT_AUTHORIZED -> "MAC not authorized"
        ConnectionProblem.PORTAL_NOT_FOUND -> "Portal not found"
        ConnectionProblem.INVALID_RESPONSE -> "Portal response problem"
        ConnectionProblem.NETWORK -> "Connection problem"
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF082B49)).padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("GOLDSTB", color = BrightGold, style = MaterialTheme.typography.displaySmall)
            Spacer(Modifier.height(34.dp))
            Text(title, color = Color.White, style = MaterialTheme.typography.headlineMedium)
            Text(problem.message, color = Color(0xFFD6E2EC), modifier = Modifier.padding(top = 12.dp), maxLines = 4)
            state.config?.mac?.let { Text("MAC: $it", color = BrightGold, modifier = Modifier.padding(top = 12.dp)) }
            Row(Modifier.padding(top = 30.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(retry, colors = ButtonDefaults.buttonColors(containerColor = BrightGold, contentColor = Color.Black)) { Icon(Icons.Filled.Refresh, null); Text(" RETRY") }
                OutlinedButton(settings) { Text("PORTAL SETTINGS") }
            }
            state.config?.mac?.let { mac ->
                TextButton(onClick = {
                    val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("GOLDSTB MAC", mac))
                }) { Icon(Icons.Filled.ContentCopy, null); Text(" COPY MAC") }
            }
        }
    }
}

@Composable private fun InfoScreen(state: AppState, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val portal = state.config?.baseUrl.orEmpty().replace(Regex("(?i)^https?://"), "").trimEnd('/')
    val rows = buildList {
        add("Current MAC" to state.config?.mac.orEmpty())
        add("Portal" to portal)
        state.accountInfo.username.takeIf { it.isNotBlank() }?.let { add("Username" to it) }
        state.accountInfo.status.takeIf { it.isNotBlank() }?.let { add("Account status" to it) }
        state.accountInfo.expires.takeIf { it.isNotBlank() }?.let { add("Expiry" to it) }
        state.accountInfo.plan.takeIf { it.isNotBlank() }?.let { add("Plan" to it) }
        state.accountInfo.server.takeIf { it.isNotBlank() && !it.equals(portal, true) }?.let { add("Server" to it) }
    }
    Column(Modifier.fillMaxSize().background(Dark).verticalScroll(rememberScrollState()).padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Back", tint = Color.White) }
            Text("ACCOUNT INFORMATION", color = BrightGold, style = MaterialTheme.typography.headlineSmall)
        }
        Spacer(Modifier.height(18.dp))
        rows.forEach { (label, value) ->
            Surface(Modifier.fillMaxWidth().padding(vertical = 5.dp), color = Panel, shape = MaterialTheme.shapes.medium) {
                Column(Modifier.padding(16.dp)) {
                    Text(label, color = Color.Gray, style = MaterialTheme.typography.labelMedium)
                    Text(value.ifBlank { "Not available" }, color = Color.White, style = MaterialTheme.typography.titleMedium)
                }
            }
        }
        if (state.accountInfo.username.isBlank()) {
            Text("The provider did not return a username. Available account details are shown above.", color = Color.Gray, modifier = Modifier.padding(top = 12.dp))
        }
    }
}

@Composable private fun LegalScreen(firstRun: Boolean, onAccept: () -> Unit, onBack: () -> Unit) {
    if (!firstRun) BackHandler(onBack = onBack)
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val compact = maxWidth < 600.dp || maxHeight < 560.dp
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(
                horizontal = if (compact) 16.dp else 64.dp,
                vertical = if (compact) 18.dp else 36.dp
            ),
            verticalArrangement = Arrangement.spacedBy(if (compact) 10.dp else 14.dp)
        ) {
            Text("GOLDSTB PRO — Legal Notice", style = if (compact) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.headlineMedium, color = Gold)
            Text("Media player only", style = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleLarge)
            Text("GOLDSTB PRO is an independent media-player client. It does not include, sell, supply, host, retransmit, or recommend channels, streams, playlists, portals, or subscriptions.")
            Text("Authorized use", style = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleLarge)
            Text("You must provide your own portal details and connect only to services and content that you are legally authorized to access. The app must not be used for pirated or unlawful content.")
            Text("Privacy", style = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleLarge)
            Text("Portal details, favourites, recent channels, profiles, and acceptance of this notice are stored locally. Connection details are sent only to the portal you choose.")
            Text("By continuing, you confirm that you understand this notice and will use the app only with authorized content.", color = Gold)
            if (compact) {
                Button(onAccept, Modifier.fillMaxWidth()) { Text(if (firstRun) "ACCEPT AND CONTINUE" else "DONE") }
                if (!firstRun) OutlinedButton(onBack, Modifier.fillMaxWidth()) { Text("BACK") }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onAccept) { Text(if (firstRun) "ACCEPT AND CONTINUE" else "DONE") }
                    if (!firstRun) OutlinedButton(onBack) { Text("BACK") }
                }
            }
        }
    }
}

@Composable private fun PlayerScreen(state: AppState, screen: Screen.Player, play: (Channel) -> Unit, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val retryScope = rememberCoroutineScope()
    val isVod = screen.channel.kind == MediaKind.VOD
    var playbackError by remember(screen.source.url) { mutableStateOf<String?>(null) }
    var automaticRetries by remember(screen.source.url) { mutableStateOf(0) }
    var retrying by remember(screen.source.url) { mutableStateOf(false) }
    var retryJob by remember(screen.source.url) { mutableStateOf<Job?>(null) }
    var fullScreen by remember { mutableStateOf(false) }
    val player = remember(screen.source.url) {
        val dataSourceFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(if (isVod) 20_000 else 8_000)
            .setReadTimeoutMs(if (isVod) 30_000 else 8_000)
            .setUserAgent(screen.source.headers["User-Agent"] ?: "GOLDSTB PRO")
            .setDefaultRequestProperties(screen.source.headers)
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(DefaultMediaSourceFactory(context).setDataSourceFactory(dataSourceFactory))
            .build()
    }
    DisposableEffect(player, screen.source.url) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (isVod && automaticRetries < 2 && retryJob?.isActive != true) {
                    automaticRetries += 1
                    retrying = true
                    playbackError = null
                    retryJob = retryScope.launch {
                        delay(3_000)
                        retrying = false
                        player.prepare()
                        player.play()
                    }
                    return
                }
                playbackError = when (error.errorCode) {
                    PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> "The portal rejected the stream request."
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> "The stream server could not be reached."
                    PlaybackException.ERROR_CODE_DECODING_FAILED,
                    PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED -> "This device cannot decode the channel format."
                    else -> error.message ?: "This channel could not be played."
                }
                if (isVod) playbackError = "This stream can't be played at this time. Please try again or go back."
            }
        }
        player.addListener(listener)
        runCatching {
            player.setMediaItem(MediaItem.fromUri(screen.source.url))
            player.prepare()
            player.playWhenReady = true
        }.onFailure { playbackError = it.message ?: "This channel could not be opened." }
        onDispose {
            retryJob?.cancel()
            player.removeListener(listener)
            player.stop()
            player.release()
        }
    }
    BackHandler { if (fullScreen) fullScreen = false else onBack() }
    val base = if (screen.channel.kind == MediaKind.LIVE) state.liveChannels else state.vodItems
    val playlist = base.filter {
        state.selectedCategory == null || state.selectedCategory == FAVORITES && it.id in state.favorites ||
            (screen.channel.kind == MediaKind.VOD || it.categoryId == state.selectedCategory)
    }
    BoxWithConstraints(Modifier.fillMaxSize().background(Dark)) {
        val sideBySide = maxWidth >= 600.dp || maxWidth > maxHeight
        val retryPlayback = {
            retryJob?.cancel()
            retryJob = null
            automaticRetries = 0
            retrying = false
            playbackError = null
            player.prepare()
            player.play()
        }
        if (fullScreen) {
            PlayerPane(player, screen.channel.name, playbackError, retrying, retryPlayback, onBack, fullScreen = true, toggleFullScreen = { fullScreen = false }, showPlaybackControls = isVod, modifier = Modifier.fillMaxSize())
        } else if (sideBySide) {
            Row(Modifier.fillMaxSize()) {
                PlayerPane(player, screen.channel.name, playbackError, retrying, retryPlayback, onBack, fullScreen = false, toggleFullScreen = { fullScreen = true }, showPlaybackControls = isVod, modifier = Modifier.weight(.67f).fillMaxHeight())
                PlaybackList(playlist, screen.channel.id, play, onBack, Modifier.weight(.33f).fillMaxHeight())
            }
        } else {
            Column(Modifier.fillMaxSize()) {
                PlayerPane(player, screen.channel.name, playbackError, retrying, retryPlayback, onBack, fullScreen = false, toggleFullScreen = { fullScreen = true }, showPlaybackControls = isVod, modifier = Modifier.fillMaxWidth().height(245.dp))
                PlaybackList(playlist, screen.channel.id, play, onBack, Modifier.fillMaxWidth().weight(1f))
            }
        }
    }
}

@Composable private fun PlayerPane(player: ExoPlayer, title: String, error: String?, retrying: Boolean, retry: () -> Unit, back: () -> Unit, fullScreen: Boolean, toggleFullScreen: () -> Unit, showPlaybackControls: Boolean, modifier: Modifier) {
    val playerFocus = remember { FocusRequester() }
    var focused by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { playerFocus.requestFocus() }
    Box(modifier
        .background(Color.Black)
        .border(if (focused && !fullScreen) 4.dp else 0.dp, BrightGold)
        .focusRequester(playerFocus)
        .onFocusChanged { focused = it.isFocused }
        .onPreviewKeyEvent { event ->
            if (event.type == KeyEventType.KeyDown && (event.key == Key.DirectionCenter || event.key == Key.Enter)) {
                toggleFullScreen()
                true
            } else false
        }
        .focusable()
    ) {
        AndroidView({ PlayerView(it).apply {
            this.player = player
            useController = showPlaybackControls
            isFocusable = false
            isFocusableInTouchMode = false
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        } }, modifier = Modifier.fillMaxSize())
        Row(Modifier.align(Alignment.TopStart).fillMaxWidth().background(Color(0x99000000)).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ArrowBack, "Back", tint = Color.White, modifier = Modifier.size(26.dp))
            Text(title, Modifier.weight(1f), color = Color.White, maxLines = 1)
            Text(if (fullScreen) "OK: EXIT FULL SCREEN" else "OK: FULL SCREEN", color = BrightGold, style = MaterialTheme.typography.labelMedium)
            Icon(if (fullScreen) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen, if (fullScreen) "Exit full screen" else "Full screen", tint = BrightGold, modifier = Modifier.padding(10.dp))
        }
        error?.let { message ->
            Column(Modifier.align(Alignment.Center).background(Color(0xEE111419)).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Playback unavailable", color = BrightGold, style = MaterialTheme.typography.titleMedium)
                Text(message, color = Color.White, modifier = Modifier.padding(vertical = 8.dp), maxLines = 3)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(retry) { Text("TRY AGAIN") }
                    OutlinedButton(back) { Text("BACK") }
                }
            }
        }
        if (retrying && error == null) {
            Row(Modifier.align(Alignment.Center).background(Color(0xDD111419)).padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(24.dp), color = BrightGold, strokeWidth = 3.dp)
                Text("Trying VOD stream again…", color = Color.White, modifier = Modifier.padding(start = 12.dp))
            }
        }
    }
}

@Composable private fun PlaybackList(items: List<Channel>, selectedId: String, play: (Channel) -> Unit, back: () -> Unit, modifier: Modifier) {
    Column(modifier.background(Color(0xFF101419))) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("PLAYLIST", color = BrightGold, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            TextButton(back) { Text("CATEGORIES") }
        }
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 7.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            items(items, key = { "player-${it.kind}-${it.id}" }) { item ->
                var focused by remember(item.id) { mutableStateOf(false) }
                Surface(
                    Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused }.clickable { play(item) }.focusable(),
                    color = if (item.id == selectedId || focused) FocusSurface else Panel,
                    border = if (item.id == selectedId || focused) androidx.compose.foundation.BorderStroke(if (focused) 4.dp else 2.dp, BrightGold) else androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF303A46))
                ) {
                    Row(Modifier.padding(horizontal = 10.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(14.dp).border(2.dp, if (item.id == selectedId || focused) BrightGold else Color(0xFF6B737C), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (item.id == selectedId) Box(Modifier.size(7.dp).background(BrightGold, CircleShape))
                        }
                        Icon(if (item.kind == MediaKind.LIVE) Icons.Filled.LiveTv else Icons.Filled.Movie, null, tint = if (item.kind == MediaKind.LIVE) Color(0xFF42A5F5) else Color(0xFFFF7043))
                        Text(item.name, Modifier.padding(start = 9.dp), color = Color.White, maxLines = 2)
                    }
                }
            }
        }
    }
}
